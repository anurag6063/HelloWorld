rm -r /var/log/2020*
