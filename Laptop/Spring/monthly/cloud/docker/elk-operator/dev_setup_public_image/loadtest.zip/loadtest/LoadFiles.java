import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.text.SimpleDateFormat;
import java.util.Date;

public class LoadFiles {

    public static void main(String[] args) {
//        args[1] = ".";
//        args[2] = "1";
//        args[0] = "C:\\Users\\vgabbireddy\\Documents\\projects\\broadcom\\documents\\development\\saas\\sampleJsons\\test1.json";
        if (args == null || args.length <= 2) {
            System.out.println("Provide args to run the program 1. sample source json file  2.Destination location" +
                    " 3.size");
            return;
        }

        createFiles(args);
    }

    private static void createFiles(String[] args){

        for (int i=1; i<=Integer.valueOf(args[2]);i++){
            Path source = Paths.get(args[0]);
            String fileName = new SimpleDateFormat("yyyMMddHHmmssSSS").format(new Date());
            StringBuilder builder = new StringBuilder();
            builder.append(fileName).append("_").append(i).append(".json");

            Path destination = Paths.get(args[1],builder.toString());
            try {
				Files.copy(source,destination, StandardCopyOption.REPLACE_EXISTING);
                System.out.println("copied file: "+destination.toString());
			} catch (IOException e) {
				e.printStackTrace();
			}
        }

    }
}

