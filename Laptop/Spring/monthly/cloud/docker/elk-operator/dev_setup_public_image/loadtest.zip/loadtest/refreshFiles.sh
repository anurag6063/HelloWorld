ls -l /var/log/2020*|wc -l
