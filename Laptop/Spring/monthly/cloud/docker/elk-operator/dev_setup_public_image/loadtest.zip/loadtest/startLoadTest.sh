# 1 source/sample file 2 destination location 3 no of files
cd /opt/loadtest/
java LoadFiles "/opt/loadtest/test1.json" "/var/log/" 1
