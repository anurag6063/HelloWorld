k cp ~/loadtest/ logstash-0:/opt/
