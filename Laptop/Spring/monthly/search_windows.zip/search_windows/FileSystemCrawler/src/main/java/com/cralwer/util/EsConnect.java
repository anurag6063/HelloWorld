package com.cralwer.util;
import org.apache.http.HttpHost;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkProcessor;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.ByteSizeUnit;
import org.elasticsearch.common.unit.ByteSizeValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
@Configuration
public class EsConnect {
	@Autowired
	Environment environment;
	private final Logger log = LoggerFactory.getLogger(EsConnect.class);
	@Bean
	public RestHighLevelClient getEsClient() {
		
		return new RestHighLevelClient(
				RestClient.builder(new HttpHost("localhost", 9200, "http")));
		
	}
	@Bean
	public BulkProcessor bulkProcessor(){
	
	
		BulkProcessor.Listener listener = new BulkProcessor.Listener() {
			int count = 0;
			@Override
			public void beforeBulk(long l, BulkRequest bulkRequest) {
				count = count + bulkRequest.numberOfActions();
				log.info("Uploaded " + count + " so far");
			}
			@Override
			public void afterBulk(long l, BulkRequest bulkRequest, BulkResponse bulkResponse) {
				log.info("file size in bytes" + bulkRequest.estimatedSizeInBytes());
				if (bulkResponse.hasFailures()) {
					for (BulkItemResponse bulkItemResponse : bulkResponse) {
						if (bulkItemResponse.isFailed()) {
							log.error("bulk response: " + bulkItemResponse.getOpType());
							BulkItemResponse.Failure failure = bulkItemResponse.getFailure();
							log.error("Error {}" , failure.toString());
						}
					}
				}
			}
			@Override
			public void afterBulk(long l, BulkRequest bulkRequest, Throwable throwable) {
				log.error("BulkProcessor error ", throwable);
				log.error("indexed no of docs {}", bulkRequest.numberOfActions());
			}
		};
		return BulkProcessor.builder(getEsClient()::bulkAsync, listener).setBulkActions(20)
				.setBulkSize(new ByteSizeValue(15, ByteSizeUnit.MB))
				.setConcurrentRequests(5).build();
//		return BulkProcessor.builder(getEsClient()::bulkAsync, listener).setBulkActions(1)
////				.setBulkSize(new ByteSizeValue(15, ByteSizeUnit.MB))
//				.setConcurrentRequests(5).build();
		
	}
	
}