package com.cralwer.service;

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

import com.cralwer.util.CralwerUtils;
import com.cralwer.util.ElasticConnectionBean;
import com.cralwer.util.EsConnect;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.databind.ObjectMapper;

@Configuration
public class CrawlAndMonitor {

	private WatchService watcher;
	private Map<WatchKey, Path> keys;
	private boolean recursive;
	private boolean trace = false;
	int failedFiles;
	int readDir;
	int readFiles;

	Logger log = LoggerFactory.getLogger(this.getClass());

	
	@Autowired
	EsConnect esConnect;
	/*
	@Autowired
	EsConnector esConnector;*/
	
	@Autowired
	ElasticConnectionBean elasticConnectionBean;
	
	@Autowired
	Environment env;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	CralwerUtils cralwerUtils;
	@Autowired
	ObjectMapper mapper;
	

	@SuppressWarnings("unchecked")
	static <T> WatchEvent<T> cast(WatchEvent<?> event) {
		return (WatchEvent<T>) event;
	}

	/*
	 * // constructor, create a watcher on fiven dir public CrawlAndMonitor(Path
	 * dir, boolean recursive) throws IOException {
	 * 
	 */

	public void startCrawl(Path dir, boolean recursive, boolean indexDataOnStartUp) throws IOException {
		this.watcher = FileSystems.getDefault().newWatchService();
		this.keys = new HashMap<WatchKey, Path>();
		this.recursive = recursive;

		// register sub dirs too
		System.out.println(LocalDateTime.now() + " registering: " + dir);

		if (recursive) {
			registerAll(dir, indexDataOnStartUp);
		} else {
			register(dir);
		}

		System.out.println(LocalDateTime.now() + " registered: " + dir);
		this.trace = true;
	}

	// register dir and sub dirs
	private void registerAll(final Path start, final boolean indexDataOnStartUp) throws IOException {

		Files.walkFileTree(start, new SimpleFileVisitor<Path>() {

			@Override
			public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
				
				if(!dir.toUri().toString().contains("software") )
				register(dir);
				readDir++;
				return FileVisitResult.CONTINUE;
			}

			
			@Override
			public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
				
				if(! (file.endsWith(".log") || file.toString().contains("software"))){
//				RestHighLevelClient client = new RestHighLevelClient(RestClient.builder(new HttpHost("10.85.18.37", 9200)));
				readFiles++;
				/*Map<String, Object> request = new HashMap<String, Object>();
				request.put("Path", file.toString());
				request.put("Creation Time", LocalDateTime.now());
				request.put("Size", attrs.size());

				log.info("request: " + mapper.writeValueAsString(request));
*/
				/*BulkRequest bulkRequest = new BulkRequest().add(new IndexRequest("fscrawler_v1", "_doc",
						Base64.getEncoder().encodeToString(file.toString().getBytes())).source(mapper.writeValueAsString(request),
						XContentType.JSON));

				esConnect.getEsClient().bulk(bulkRequest);*/
//				client.bulk(bulkRequest);
				
				/*
				esConnector.bulkProcessor().add(new IndexRequest("fscrawler_v1", "_doc",
						Base64.getEncoder().encodeToString(file.toString().getBytes())).source(mapper.writeValueAsString(request),
						XContentType.JSON));*/
				
				/*BulkProcessor bulkRequest = esConnector.bulkProcessor().add(new IndexRequest("fscrawler_v1", "_doc",
						Base64.getEncoder().encodeToString(file.toString().getBytes())).source(mapper.writeValueAsString(request),
						XContentType.JSON));
				
				bulkRequest.flush();
				esConnector.getEsClient().bulk(bulkRequest, headers)
				elasticConnectionBean.bulkProcessor().add(new IndexRequest("fscrawler_v1", "_doc",
						Base64.getEncoder().encodeToString(file.toString().getBytes())).source(mapper.writeValueAsString(request),
						XContentType.JSON));
				*/
				
				// call ES on first run when a file is getting registered. only
				// file names and their properties.
			/*	HttpHeaders httpHeaders = new HttpHeaders();
				httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");

				Map<String, Object> request = new HashMap<String, Object>();
				request.put("Path", file.toString());
				request.put("Creation Time", LocalDateTime.now());
				request.put("Size", attrs.size());
				if(indexDataOnStartUp)
				request.put("data", Base64.getEncoder().encodeToString(FileUtils.readFileToByteArray(file.toFile())));

				log.info("request: " + mapper.writeValueAsString(request));
				// String _id = cralwerUtils.encodeValue(file.toString());

				HttpEntity<String> httpEntity = new HttpEntity<String>(mapper.writeValueAsString(request),
						createHttpHeaders(httpHeaders));
				String response = restTemplate.postForObject(
						"http://localhost:9200/my_files_v1/_doc/"
								+ Base64.getEncoder().encodeToString(file.toString().getBytes())+ "?pipeline=attachment",
						httpEntity, String.class);
				log.info("index response: " + response.toString());
*/
//				System.out.println("Read file:" + file + " attrs creation time: " + attrs.creationTime() + " size: "
//						+ attrs.size());
//				readFiles++;
				
				// if data does not be indexed then dont create the doc.
				if(indexDataOnStartUp){
				createEsDoc(file,indexDataOnStartUp);
				}else{
					System.out.println("Not creating doc on regitering");
				}
			}
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
				failedFiles++;
				System.out.println(" Failer reading path: " + file.toString());
				return FileVisitResult.CONTINUE;
			}

			@Override
			public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {

				// call ES
				System.out.println(" Registering All: " + dir);
				return FileVisitResult.CONTINUE;
			}
		});

	}

	// register dir
	public void register(Path dir) throws IOException {

		WatchKey key = dir.register(watcher, java.nio.file.StandardWatchEventKinds.ENTRY_CREATE,
				java.nio.file.StandardWatchEventKinds.ENTRY_DELETE, java.nio.file.StandardWatchEventKinds.ENTRY_MODIFY);

		if (trace) {

			Path prev = keys.get(key);
			if (null == prev) {

				System.out.format("register: %s\n", dir);

			} else {
				if (!dir.equals(prev)) {
					System.out.println("Updating Registry: " + dir);
				}
			}
		}

		keys.put(key, dir);
	}

	public void processEvents() throws IOException {

		log.info("Processing Events Started , files read: {}, files failed: {} , dirs read {}", readFiles,failedFiles, readDir );
		for (;;) {

			// must be key
			WatchKey watchKey;

			try {
				watchKey = watcher.take();
			} catch (InterruptedException ie) {
				return;
			}

			Path dir = keys.get(watchKey);
			if (null == dir) {
				System.err.println("WatchKey not recognized!!");
				continue;
			}

			for (WatchEvent<?> event : watchKey.pollEvents()) {

				WatchEvent.Kind kind = event.kind();
				log.info("Kind of event: " + kind.name());

				// TBD - provide example of how OVERFLOW event is handled
				if (kind == java.nio.file.StandardWatchEventKinds.OVERFLOW) {
					System.err.println("Watcher found overflowing: " + dir);
					continue;
				}
				WatchEvent<Path> ev = cast(event);

				Path name = ev.context();
				Path child = dir.resolve(name);
				
				log.info("Is action of file: {} , file path {} ", child.toAbsolutePath().toFile().isFile(),
						child.toAbsolutePath());

				System.out.format(" Event: %s : for dir %s , at %s  \n", event.kind().name(), child,
						LocalDateTime.now());

				if (java.nio.file.StandardWatchEventKinds.ENTRY_DELETE == kind) {
					log.info("deleting file or folder.");
					deleteFileOrFolder(child);
				} else if (child.toAbsolutePath().toFile().isFile()) {

					log.info("Taking create or update of file.");
					createEsDoc(child, true);

				} else if (child.toAbsolutePath().toFile().isFile() || !child.toAbsolutePath().toFile().isDirectory()) {
					// if its not a file and not a dir too and event is modify its actually deleted.
					deleteFileOrFolder(child);
				}
				/*
				 * HashMap<String,String> value = new HashMap<String,String>(){{
				 * put("value", child.toString()); }};
				 * 
				 * HashMap<String,Object> keyword = new
				 * HashMap<String,Object>(){{ put("dir.keyword", value); }};
				 * 
				 * HashMap<String,Object> term = new HashMap<String,Object>(){{
				 * put("term", keyword); }};
				 * 
				 * HashMap<String,Object> query = new HashMap<String,Object>(){{
				 * put("query", term); }};
				 * 
				 * mapper.writeValueAsString(query);
				 * 
				 * log.info("request: " +
				 * mapper.writeValueAsString(mapper.writeValueAsString(query)));
				 * 
				 * HttpEntity<String> httpEntity = new
				 * HttpEntity<String>(mapper.writeValueAsString(query),
				 * createHttpHeaders(httpHeaders)); String response =
				 * restTemplate.postForObject(
				 * "http://localhost:9200/fscrawler_v4/_search", httpEntity,
				 * String.class); log.info("index response: " +
				 * response.toString());
				 * 
				 * JsonNode responseJsonNode =
				 * mapper.readTree(response.toString()); JsonNode hits =
				 * (responseJsonNode.get("hits")).get("hits"); hits.isArray();
				 * if(child.toFile().isFile()){ if( 0 != hits.size()){
				 * 
				 * // warn that more than one doc will be deleted.
				 * System.err.println("More than one docs found.");
				 * 
				 * ArrayList<String> idsToBeDeleted = new ArrayList<>();
				 * hits.forEach(hit->{
				 * idsToBeDeleted.add(hit.get("_id").toString()); });
				 * 
				 * mapper.writeValueAsString(idsToBeDeleted);
				 * 
				 * HashMap<String, ArrayList<String>> values = new
				 * HashMap<String,ArrayList<String>>(){{ put("values",
				 * idsToBeDeleted); }};
				 * 
				 * HashMap<String,Object> ids = new HashMap<String,Object>(){{
				 * put("ids", values); }};
				 * 
				 * HashMap<String,Object> query2 = new
				 * HashMap<String,Object>(){{ put("query", ids); }};
				 * 
				 * 
				 * log.info("request: " +
				 * mapper.writeValueAsString(mapper.writeValueAsString(query2)))
				 * ;
				 * 
				 * 
				 * 
				 * } else {
				 * 
				 * 
				 * Map<String, Object> request = new HashMap<String, Object>();
				 * request.put("dir", child.toUri().toString()); request.put(
				 * "Creation Time", child.toFile().lastModified());
				 * request.put("size", child.toFile().getTotalSpace());
				 * 
				 * log.info("request: " + mapper.writeValueAsString(request));
				 * 
				 * HttpEntity<String> httpEntity3 = new
				 * HttpEntity<String>(mapper.writeValueAsString(request),
				 * createHttpHeaders(httpHeaders)); String response3 =
				 * restTemplate.postForObject(
				 * "http://localhost:9200/fscrawler_v4/_doc/", httpEntity3,
				 * String.class); log.info("index response: " +
				 * response3.toString()); } }
				 * 
				 * 
				 * // my code ends }
				 */

				// if new dir is created and we are watching recursively:
				// register dir and its sub dir

				if (recursive && (kind == java.nio.file.StandardWatchEventKinds.ENTRY_CREATE)) {
					try {
						// creation call ES in register
						if (Files.isDirectory(child, java.nio.file.LinkOption.NOFOLLOW_LINKS)) {
							registerAll(child, true);
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}

			}

			// remove key it dirs is deleted:
			boolean valid = watchKey.reset();
			if (!valid) {

				// call ES delete
				keys.remove(watchKey);

				// if all is inaccessible
				if (keys.isEmpty()) {
					break;
				}
			}
		}

	}

	private void createEsDoc(Path file, boolean indexDataOnStartUp) throws IOException {

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");

		Map<String, Object> request = new HashMap<String, Object>();
		request.put("Path", FilenameUtils.separatorsToUnix(file.toString()));
		request.put("Json Created Time", LocalDateTime.now());
		request.put("Size", file.toFile().getTotalSpace());
		BasicFileAttributes attrs = Files.readAttributes(file, BasicFileAttributes.class);
		
		request.put("Creation Time", attrs.creationTime().toString());
		request.put("Accessed Time", attrs.lastAccessTime().toString());
		request.put("Is Regular File", attrs.isRegularFile());
		request.put("Modified Time", attrs.lastModifiedTime().toString());
		request.put("File Size", attrs.size());
		
		if(indexDataOnStartUp){
		request.put("data", Base64.getEncoder().encodeToString(FileUtils.readFileToByteArray(file.toFile())));
		}
		else{
			System.out.println("Data not being sent again");
		}
		mapper.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);

//		log.info("request: " + mapper.writeValueAsString(request));

		HttpEntity<String> httpEntity = new HttpEntity<String>(mapper.writeValueAsString(request),
				createHttpHeaders(httpHeaders));
		System.err.println("URL " + "http://localhost:9200/my_files_v2/_doc/"
				+ Base64.getEncoder().encodeToString(file.toString().getBytes()));
		/*String response = restTemplate.postForObject("http://localhost:9200/fscrawler_v4/_doc/"
				+ Base64.getEncoder().encodeToString(child.toString().getBytes()), httpEntity, String.class);
		*/
		String response= "no response";
		
		try{
		if(indexDataOnStartUp){
		response = restTemplate.postForObject(
				"http://localhost:9200/my_files_v2/_doc/"
						+ Base64.getEncoder().encodeToString(file.toString().getBytes())+ "?pipeline=attachment",
				httpEntity, String.class);
		} else{
			response = restTemplate.postForObject(
					"http://localhost:9200/my_files_v2/_doc/"
							+ Base64.getEncoder().encodeToString(file.toString().getBytes()),
					httpEntity, String.class);
		}
		log.info("index response: " + response.toString());
		}catch(Exception e)
		{
			System.err.println("Error in indexing!");
			e.printStackTrace();
		restTemplate.getForObject(
				"http://localhost:9200/my_files_v2_error/_doc/"
						+ Base64.getEncoder().encodeToString(file.toString().getBytes()), String.class);
		}
	}

	private void deleteFileOrFolder(Path dir) {

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set(HttpHeaders.CONTENT_TYPE, "application/json");

		System.err.println("URL " + "http://localhost:9200/my_files_v2/_doc/"
				+ Base64.getEncoder().encodeToString(dir.toString().getBytes()));

		try {
			restTemplate.delete("http://localhost:9200/my_files_v2/_doc/"
					+ Base64.getEncoder().encodeToString(dir.toString().getBytes()));
			log.info(" successful delete for : " + Base64.getEncoder().encodeToString(dir.toString().getBytes())
					+ " having dir: " + dir.toString());

		} catch (Exception e) {
			log.error("FAILED : delete for : " + Base64.getEncoder().encodeToString(dir.toString().getBytes())
					+ " having dir: " + dir.toString());
			e.printStackTrace();
		}
	}

	private HttpHeaders createHttpHeaders(HttpHeaders httpHeaders) {
		log.debug("createHttpHeaders() Enter");
		ArrayList<MediaType> arrayList = new ArrayList<MediaType>();
		arrayList.add(MediaType.APPLICATION_JSON);
		httpHeaders.setAccept(arrayList);
		StringBuilder authorizationBuilder = new StringBuilder("elastic");
		authorizationBuilder.append(":");
		authorizationBuilder.append("elastic123");
		httpHeaders.add(HttpHeaders.AUTHORIZATION,
				"Basic " + Base64.getEncoder().encodeToString(authorizationBuilder.toString().getBytes()));
		log.info("httpHeaders {}", httpHeaders);
		log.debug("createHttpHeaders() Exit");
		return httpHeaders;
	}
}
