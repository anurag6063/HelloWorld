# search_windows
Full text search folder on Windows


This is to let you search contents in all the files in a particular directory on your windows machine.
