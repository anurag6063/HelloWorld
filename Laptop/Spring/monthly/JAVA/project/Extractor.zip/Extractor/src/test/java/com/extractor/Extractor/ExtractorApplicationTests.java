package com.extractor.Extractor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExtractorApplicationTests {

	@Test
	void contextLoads() {
	}

}
