package com.es;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.es.impl.PullDataDAOImpl;

@RestController
public class Controller {

	@Autowired PullDataDAOImpl pullDataDAOImpl;
	
	@ResponseBody
	@GetMapping(value = "/")
	public String fetchData(){
		pullDataDAOImpl.fetchData();
		return null;
	}
	
	
}
