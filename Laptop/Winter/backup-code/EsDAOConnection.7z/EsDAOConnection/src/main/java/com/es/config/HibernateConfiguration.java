package com.es.config;

import java.util.Properties;

import javax.sql.DataSource;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.orm.hibernate5.LocalSessionFactoryBean;

/**
 * This is Hibernate Configuration class 
 * @author ravishankar9
 *
 */
@Configuration
@ComponentScan({ "com.es" })

public class HibernateConfiguration {
 
	@Value("${database.driver}") String driverName;
	@Value("${database.url}") String databaseUrl;
	@Value("${database.user}") String databaseUser;
	@Value("${database.password}") String databasePassword;
	@Value("${hibernate.dialect}") String hibernateDialect;
	@Value("${hibernate.show_sql}") String hibernateShow_sql;
	@Value("${hibernate.hbm2ddl.auto}") String hibernateHbm2ddlAuto;



	/**
	 * This method is to get the Hibernate Session factory
	 * @return hibernate session factory
	 */
    @Bean
    public LocalSessionFactoryBean sessionFactory() {
        LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(dataSource());
        sessionFactory.setPackagesToScan(new String[] { "com.es.entity" });//Specify packages to search for autodetection of your entity classes in the classpath.
        sessionFactory.setHibernateProperties(hibernateProperties());
        return sessionFactory;
     }
     
    /**
     * This method is to get the datasource
     * @return datasource
     */
    @Bean
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverName);
        dataSource.setUrl(databaseUrl);
        dataSource.setUsername(databaseUser);
        dataSource.setPassword(databasePassword);
      
        return dataSource;
    }
     
    /**
     * This method loads the hibenrate properties and returns it
     * @return hibernate properties
     */
    private Properties hibernateProperties() {
        Properties properties = new Properties();
        properties.put("hibernate.dialect", hibernateDialect);
        properties.put("hibernate.show_sql", hibernateShow_sql);
        properties.put("hibernate.hbm2ddl.auto", hibernateHbm2ddlAuto);
        return properties;        
    }
     
    
    /**
     * This method returns the Hibernate Tempalet
     * @param sessionFactory
     * @return HibernateTemplate
     */
    @Bean
    @Autowired
    public HibernateTemplate getHibernateTemplate(SessionFactory sessionFactory)
    {
        return new HibernateTemplate(sessionFactory);
    }
    
}