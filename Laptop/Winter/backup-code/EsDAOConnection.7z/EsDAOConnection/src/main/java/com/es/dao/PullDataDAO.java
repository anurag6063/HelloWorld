package com.es.dao;

public interface PullDataDAO {
	
	public void fetchData();

}
