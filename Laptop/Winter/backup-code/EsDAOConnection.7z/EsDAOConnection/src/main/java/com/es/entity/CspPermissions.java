/*package com.es.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="CSP_PERMISSIONS", schema="CSP")
public class CspPermissions {
	
	
	@Id
	@Column(name="USER_ID")
	Integer UserId;
	
	Integer PERMISSION_ID;
	
	Integer DOCUMENT_ID;
	
	String RECORD_ACTIVITY;
	
	Date CREATE_DATE;
	
	Date UPDATE_DATE;
	
	String CREATED_BY;
	
	String UPDATED_BY;
	
	String BOXGROUP_ID;

	public Integer getUserId() {
		return UserId;
	}

	public void setUserId(Integer userId) {
		UserId = userId;
	}

	public Integer getPERMISSION_ID() {
		return PERMISSION_ID;
	}

	public void setPERMISSION_ID(Integer pERMISSION_ID) {
		PERMISSION_ID = pERMISSION_ID;
	}

	public Integer getDOCUMENT_ID() {
		return DOCUMENT_ID;
	}

	public void setDOCUMENT_ID(Integer dOCUMENT_ID) {
		DOCUMENT_ID = dOCUMENT_ID;
	}

	public String getRECORD_ACTIVITY() {
		return RECORD_ACTIVITY;
	}

	public void setRECORD_ACTIVITY(String rECORD_ACTIVITY) {
		RECORD_ACTIVITY = rECORD_ACTIVITY;
	}

	public Date getCREATE_DATE() {
		return CREATE_DATE;
	}

	public void setCREATE_DATE(Date cREATE_DATE) {
		CREATE_DATE = cREATE_DATE;
	}

	public Date getUPDATE_DATE() {
		return UPDATE_DATE;
	}

	public void setUPDATE_DATE(Date uPDATE_DATE) {
		UPDATE_DATE = uPDATE_DATE;
	}

	public String getCREATED_BY() {
		return CREATED_BY;
	}

	public void setCREATED_BY(String cREATED_BY) {
		CREATED_BY = cREATED_BY;
	}

	public String getUPDATED_BY() {
		return UPDATED_BY;
	}

	public void setUPDATED_BY(String uPDATED_BY) {
		UPDATED_BY = uPDATED_BY;
	}

	public String getBOXGROUP_ID() {
		return BOXGROUP_ID;
	}

	public void setBOXGROUP_ID(String bOXGROUP_ID) {
		BOXGROUP_ID = bOXGROUP_ID;
	} 

	
	
}
*/