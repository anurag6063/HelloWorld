package com.es;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.es.impl.PullDataDAOImpl;

@SpringBootApplication
public class EsDaoConnectionApplication {

	public static void main(String[] args) {
		ApplicationContext applicationContext=	SpringApplication.run(EsDaoConnectionApplication.class, args);
		
		/*System.out.println(applicationContext.containsBean("PullDataDAOImpl"));
		applicationContext.getBean(PullDataDAOImpl.class).fetchData();*/
	}
}
