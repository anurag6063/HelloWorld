package com.es.impl;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.SQLQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate5.HibernateTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.es.dao.PullDataDAO;
/*import com.es.entity.CspPermissions;*/

@Repository
@Transactional
public class PullDataDAOImpl implements PullDataDAO{

	
	@Autowired HibernateTemplate hibernateTemplate;
	
	@Override
	public void fetchData() {

		String queryString = "select * from CSP.CSP_PERMISSIONS" ;
		List list= hibernateTemplate.getSessionFactory().getCurrentSession().createSQLQuery(queryString).list();
		
	
		System.out.println(list.size());
	}
	
	
  

}
