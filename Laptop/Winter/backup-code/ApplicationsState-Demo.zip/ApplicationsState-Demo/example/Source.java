
package com.example;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Application",
    "Date",
    "Status"
})
public class Source {

    @JsonProperty("Application")
    private String application;
    @JsonProperty("Date")
    private String date;
    @JsonProperty("Status")
    private List<String> status = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("Application")
    public String getApplication() {
        return application;
    }

    @JsonProperty("Application")
    public void setApplication(String application) {
        this.application = application;
    }

    @JsonProperty("Date")
    public String getDate() {
        return date;
    }

    @JsonProperty("Date")
    public void setDate(String date) {
        this.date = date;
    }

    @JsonProperty("Status")
    public List<String> getStatus() {
        return status;
    }

    @JsonProperty("Status")
    public void setStatus(List<String> status) {
        this.status = status;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("application", application).append("date", date).append("status", status).append("additionalProperties", additionalProperties).toString();
    }


/*
public class Source
{
private String[] Status;

private String Date;

private String Application;

public String[] getStatus ()
{
return Status;
}

public void setStatus (String[] Status)
{
this.Status = Status;
}

public String getDate ()
{
return Date;
}

public void setDate (String Date)
{
this.Date = Date;
}

public String getApplication ()
{
return Application;
}

public void setApplication (String Application)
{
this.Application = Application;
}

@Override
public String toString()
{
return "ClassPojo [Status = "+Status+", Date = "+Date+", Application = "+Application+"]";
}
*/
}
