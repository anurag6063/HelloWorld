package com.example.demo;

import java.io.File;
import java.io.IOException;
import java.util.List;

import com.example.Aggregations;
import com.example.NestedServerAgg;
import com.example.Source;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class Util {

	public void convert() {
		
		
		ObjectMapper map = new ObjectMapper();
		
		try {
//			Aggregations agg = map.readValue(new File("C:/Temp/response.json"), Aggregations.class);
			
			Source agg = map.readValue(new File("C:/Temp/doc.json"), Source.class);
			
			System.out.println(agg.getApplication() + agg.getDate()+ agg.getStatus());
/*
			NestedServerAgg nsa = agg.getDateAgg().getBuckets().get(0).getNestedServerAgg();
			
			List<com.example.Bucket> busket =agg.getDateAgg().getBuckets();
		*/
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
