
package com.example;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "key",
    "doc_count",
    "get_docs"
})
public class Bucket_ {

    @JsonProperty("key")
    private String key;
    @JsonProperty("doc_count")
    private Integer docCount;
    @JsonProperty("get_docs")
    private GetDocs getDocs;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("key")
    public String getKey() {
        return key;
    }

    @JsonProperty("key")
    public void setKey(String key) {
        this.key = key;
    }

    @JsonProperty("doc_count")
    public Integer getDocCount() {
        return docCount;
    }

    @JsonProperty("doc_count")
    public void setDocCount(Integer docCount) {
        this.docCount = docCount;
    }

    @JsonProperty("get_docs")
    public GetDocs getGetDocs() {
        return getDocs;
    }

    @JsonProperty("get_docs")
    public void setGetDocs(GetDocs getDocs) {
        this.getDocs = getDocs;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

   /* @Override
    public String toString() {
        return new ToStringBuilder(this).append("key", key).append("docCount", docCount).append("getDocs", getDocs).append("additionalProperties", additionalProperties).toString();
    }*/

}
