package com.server.connectEs;

import java.net.InetAddress;
import java.util.StringTokenizer;

import javax.annotation.PostConstruct;

import org.elasticsearch.client.Client;
import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.server.status.AppStateConstants;
@Configuration
public class ClientConnection {

	@PostConstruct
	public void init() {
	}

	@Bean
	public static Client getEsClient() {
		Client client = null;

		try {
			Settings settings = Settings.settingsBuilder().put("cluster.name", AppStateConstants.CLUSTER).build();
			TransportClient transportClient = TransportClient.builder().settings(settings).build();
			String transPortAddress = AppStateConstants.LOCALHOST;
			StringTokenizer st = new StringTokenizer(transPortAddress, ",");
			while (st.hasMoreTokens()) {
				String transPortAddr = st.nextToken();
				transportClient = transportClient
						.addTransportAddress(new org.elasticsearch.common.transport.InetSocketTransportAddress(
								InetAddress.getByName(transPortAddr), AppStateConstants.PORT));
			}

			client = transportClient;
		} catch (Exception ex) {
			// logger.error("Error occurred while creating search client!", ex);
		}

		System.out.println("Bean instantiated");
		return client;
	}

}
