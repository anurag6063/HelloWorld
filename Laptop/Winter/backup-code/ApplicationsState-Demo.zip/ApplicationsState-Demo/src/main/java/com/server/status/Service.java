package com.server.status;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.net.URI;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TimeZone;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Client;
import org.elasticsearch.search.aggregations.Aggregation;
import org.elasticsearch.search.aggregations.Aggregations;
import org.elasticsearch.search.aggregations.bucket.terms.Terms;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.server.connectEs.ClientConnection;


@Configuration
@ComponentScan(basePackages ={"com.server.connectEs"})
public class Service {

	
	Integer colSize=7+1;

	
	@Autowired Utilities utilities;
	
	@Bean
	public Client getTransportClient()
	{
	    return ClientConnection.getEsClient();
	}
	
	
	public SearchResponse searching(String startDate , String endDate)
	{
		 
		
		String query = utilities.getQuery(startDate , endDate);
		
		Client esClient = getTransportClient();
    	SearchResponse searchResponse = esClient.prepareSearch(AppStateConstants.INDEX).setTypes(AppStateConstants.TYPE).setSource(query).execute()
				.actionGet();
    
    	
    	return searchResponse;
	}


	public int findDateRange(String date, String tz) throws ParseException {
		int startFrom = 0;
		if(!date.equals("0"))
		{
			startFrom = compareDate(date,tz);
		}
		
		return startFrom;
	
		
		
	}
	
	public static int compareDate(String indate, String tz) throws ParseException
	{
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(AppStateConstants.DATE_FORMAT);

		LocalDate givenDate = LocalDate.parse(indate, formatter); 
		
		LocalDate dateToday = LocalDate.now(ZoneId.of(tz))  ;
 		
		long diff = ChronoUnit.DAYS.between(dateToday, givenDate);
//		System.out.println("Difference in Date : "+givenDate.compareTo(dateToday));

// 		return givenDate.compareTo(dateToday) ;
		return (int) diff;
    }


	ArrayList<String> dateInHeaderJava8(int fromdate, String tz)
	{
		ArrayList<String> header = new ArrayList<>();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern(AppStateConstants.DATE_FORMAT);
		
//		LocalDateTime now = LocalDateTime.now(ZoneId.of(AppStateConstants.ZONE));
		LocalDateTime now = LocalDateTime.now(ZoneId.of(tz));
		
		if(fromdate < 0){
		    now = now.minusDays(Math.abs(fromdate));
		}else
		{
		    now = now.plusDays(Math.abs(fromdate));

		}
		
	    header.add("\""+now.format(formatter)+"\"");
	     for(int i = 0; i< 6; i++){
	    	    now = now.minusDays(1);
//			    System.out.println(" dates are  "+i +" :  "+now.format(formatter));
			    header.add("\""+now.format(formatter)+"\"");
	     }
	     
			header.add(0, "\""+"Services"+"\"");

		return header;
		
	}
	
	
	
	
	ArrayList<String> dateInHeader(int fromdate)
	{
		
		
		ArrayList<String> header = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy ");
	
		Calendar cal = Calendar.getInstance();
//		System.out.println(sdf.format(cal.getTime()));

		sdf.setTimeZone(TimeZone.getTimeZone("PST"));
		String todayDate = sdf.format(cal.getTime());
		
//		cal.setTimeZone(TimeZone.getTimeZone("PST"));
//		System.out.println(sdf.format(cal.getTime()));
		// get starting date
		cal.add(Calendar.DAY_OF_YEAR, fromdate-7);

		// loop adding one day in each iteration
		for(int i = 0; i< 7; i++){
		    cal.add(Calendar.DAY_OF_YEAR, 1);
		    sdf.setTimeZone(TimeZone.getTimeZone("PST"));
//		    System.out.println("dates are "+sdf.format(cal.getTime()));
		    header.add("\""+sdf.format(cal.getTime())+"\"");
	}
		header.add(0, "\""+"Services"+"\"");
//		header.forEach(System.out::println);
		
	/*	for(String temp : header)
		{
			temp = temp.toString();
			header.add(temp);
		}*/
		return header;
}

	ArrayList<String> dateInHeaderWithoutQuotes(int fromdate)
	{
		
		
		ArrayList<String> header = new ArrayList<>();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy ");
	
		Calendar cal = Calendar.getInstance();
//		System.out.println(sdf.format(cal.getTime()));

		sdf.setTimeZone(TimeZone.getTimeZone("PST"));
		String todayDate = sdf.format(cal.getTime());
		
//		cal.setTimeZone(TimeZone.getTimeZone("PST"));
//		System.out.println(sdf.format(cal.getTime()));
		// get starting date
		cal.add(Calendar.DAY_OF_YEAR, fromdate-7);

		// loop adding one day in each iteration
		for(int i = 0; i< 7; i++){
		    cal.add(Calendar.DAY_OF_YEAR, 1);
		    sdf.setTimeZone(TimeZone.getTimeZone("PST"));
//		    System.out.println("dates are "+sdf.format(cal.getTime()));
		    header.add(sdf.format(cal.getTime()));
	}
		header.add(0, "\""+"Services"+"\"");
//		header.forEach(System.out::println);
		
	/*	for(String temp : header)
		{
			temp = temp.toString();
			header.add(temp);
		}*/
		return header;
}


	public SearchResponse searchingToday() {
		// TODO Auto-generated method stub

		String query = " { \"size\": 0, \"query\": { \"range\" : {  \"date\" : {  \"gte\" : \"now-0d/d\",\"lte\":\"now-0d/d\" } } }, \"aggs\" : { \"serverAgg\" : { \"terms\": {  \"field\": \"application\", \"size\": 30, \"order\": { \"_count\": \"desc\" } } , \"aggs\": { \"nestedDateAgg\":{ \"date_histogram\" : { \"field\" : \"date\", \"interval\" : \"1D\", \"format\" : \"dd-MM-yyyy\" , \"order\": { \"_key\": \"asc\" }}, \"aggs\": { \"getDocs\": { \"top_hits\": { \"size\": 10 } } } } } } } } ";
//		String query = " { \"size\": 0, \"query\": { \"range\" : {  \"date\" : {  \"gte\" : \"now"+String.valueOf((start-6))+"d/d\",\"lte\":\"now"+end+"d/d\" } } }, \"aggs\" : { \"serverAgg\" : { \"terms\": {  \"field\": \"application\", \"size\": 30, \"order\": { \"_count\": \"desc\" } } , \"aggs\": { \"nestedDateAgg\":{ \"date_histogram\" : { \"field\" : \"date\", \"interval\" : \"1D\", \"format\" : \"dd-MM-yyyy\" , \"order\": { \"_key\": \"asc\" }}, \"aggs\": { \"getDocs\": { \"top_hits\": { \"size\": 10 } } } } } } } } ";
		
		Client esClient = getTransportClient();
    	SearchResponse searchResponse = esClient.prepareSearch(AppStateConstants.INDEX).setTypes(AppStateConstants.TYPE).setSource(query).execute()
				.actionGet();
    
    	
    	return searchResponse;

		
	}


	public void getSearchResponseInjava(SearchResponse searchResponse) {
		// TODO Auto-generated method stub
		
		Terms  servers= searchResponse.getAggregations().get("serverAgg");
		List<Terms.Bucket> bucket = servers.getBuckets();
		
		for(Terms.Bucket tempTerm : bucket)
		{
			Aggregations internalAgg = tempTerm.getAggregations();
//			System.out.println(internalAgg.toString());
		}
		Terms.Bucket b = bucket.get(0);
		Aggregations dates2 =b.getAggregations();
//		dates2.getProperty(path)
		Map<String,Aggregation> map = dates2.getAsMap();
		
		Set<String> keys = map.keySet();
		Aggregation dateA =map.get("nestedDateAgg");
//		dateA.
		
		for (Terms.Bucket bucket1 : bucket)
	      {
			
			Terms  dates= bucket1.getAggregations().get("nestedDateAgg");
			Collection<Terms.Bucket> bucketDate = dates.getBuckets();
			
//	        Aggregations a1 = bucket1.getAggregations();
	        String path = bucket1.getKeyAsString();
	        long pathcount = bucket1.getDocCount();

	        for (Terms.Bucket dateOne : bucketDate)
	        {	
	        	
//	        	System.out.println("");
	        	/*List<Aggregation> terms = a1.asList();
	        	Aggregation a = terms.get(0);
	        	a.
	        	System.out.println(a.toString());
//	        	a.getProperty(path)
//*/	       
	        	//Object id =a.getProperty("_id");
	        	
	         /* TopHits ht = (InternalTopHits)anA1;
	          SearchHits ht1 = ht.getHits();
	          SearchHit[] ht1_arr =  ht1.hits();
	          for (SearchHit ht11 : ht1_arr)
	          {
//	            logger.info(String.format("filepath_original %s id - %s,  ", path, ht11.getIndex() + "/" + ht11.getType() + "/" + ht11.getId() ));
//	        	list.add(new IndexDocIdentifier(path, ht11.getIndex(), ht11.getType(), ht11.getId()));
	          }*/
	        }
//	        result.put(path, list);
	      }}
		
	
	
	
	public void parsingSearchRes(SearchResponse searchResponse) throws JsonProcessingException, IOException
	{
		
		String output= searchResponse.toString();
		ObjectMapper mapper = new ObjectMapper();
		JsonNode actualObj = mapper.readTree(output);
//		System.out.println("Starting");
		
//		System.out.println(actualObj.get("timed_out"));
		
		JsonNode aggs = actualObj.get("aggregations");
		
		JsonNode serverAgg = aggs.get("serverAgg").get("buckets");
		JsonNode server = serverAgg.get(0);
		
		
		JsonNode serverName = server.get("key");
		JsonNode nestedDate = serverName.get("nestedDateAgg");
		
		
//		System.out.println(aggs.get("serverAgg").get("buckets"));
		
		
//		System.out.println(actualObj.get("aggregations"));
		
//		System.out.println("");
		
//		Histogram agg = sr.getAggregations().get("serverAgg");
//		System.out.println("");
	}
	
	
	
	public String[][] searchResMixed(SearchResponse searchResponse, int start, String tz) throws JsonProcessingException, IOException
	{
		// creating 2D array 
		String output= searchResponse.toString();
		ObjectMapper mapper = new ObjectMapper();
		JsonNode response = mapper.readTree(output);
		
		Integer rowSize= response.get("aggregations").get("serverAgg").get("buckets").size()+1;
	    // row
		String[][] table = new String[rowSize][colSize];
		
		for(int row=0 ; row< rowSize; row ++)
		{
			for(int col=0; col< colSize; col++)
			{
				table[row][col]="N/A";
			}
		}

		ArrayList<String> header=dateInHeaderJava8(start, tz);
		for(int col=0;col< 8 ; col++)
		{
			table[0][col]=header.get(col);
		}

		
		for(int row=1 ; row<rowSize; row ++)
		{
			table[row][0]=response.get("aggregations").get("serverAgg").get("buckets").get(row-1).get("key").toString();
		}

		// find the key and date
		for(int row=1 ; row<rowSize; row ++)
		{

			int dateBuckSize =response.get("aggregations").get("serverAgg").get("buckets").get(row-1).get("nestedDateAgg").get("buckets").size();
			
			for(int colBuck=0; colBuck<dateBuckSize;colBuck++)
			{
				String key =response.get("aggregations").get("serverAgg").get("buckets").get(row-1).get("nestedDateAgg").get("buckets").get(colBuck).get("getDocs").get("hits").get("hits").get(0).get("_source").get("application").toString();
//				System.out.println("Application "+key);
				
				String date =response.get("aggregations").get("serverAgg").get("buckets").get(row-1).get("nestedDateAgg").get("buckets").get(colBuck).get("getDocs").get("hits").get("hits").get(0).get("_source").get("date").asText();
//				System.out.println("Date "+date);
				
				JsonNode statusArray =response.get("aggregations").get("serverAgg").get("buckets").get(row-1).get("nestedDateAgg").get("buckets").get(colBuck).get("getDocs").get("hits").get("hits").get(0).get("_source").get("status");
				if(key.contains("Applications - Oracle Dmantra")){
					System.out.println();
				}
				for (int stausHit = 0 ; stausHit < statusArray.size(); stausHit++) {
        			table = populateDotsStatus(statusArray.get(stausHit) ,date,tz, key, table, rowSize);
				}
			}
			String key =response.get("aggregations").get("serverAgg").get("buckets").get(row-1).get("key").toString();

		}

		
		// add "" on both sides
		for(int row=1 ; row< rowSize; row ++)
		{
			for(int col=1; col< colSize; col++)
			{
				table[row][col]="\""+table[row][col]+"\"";
			}
		}
		
		return table;
	}


	private String[][] populateDotsStatus(JsonNode statusArrayIn, String date , String tz, String key, String[][] table, Integer rowSize ) {
		
		ObjectNode statusArrayON = (ObjectNode) statusArrayIn;
		if(statusArrayON.get("description").textValue().trim().length() != 0)
		{
			statusArrayON.put("description", ", "+ statusArrayON.get("description").textValue());
		}
		 JsonNode statusArray= statusArrayON;
		
		String oneDot = " ";
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
		String ldtEndString= "N/A";
		Integer conditionType = 1;
		String endDateZoned=null;
		
	    				String startTime =statusArray.get("startTime").textValue();
	    				if(startTime.length()==4){
	    					
	    					startTime="0"+startTime;
	    				}
	    				
	    				/*if(statusArray.get("status").toString().contains("Down") || statusArray.get("status").toString().contains("Disrupted"))
	    				{
	    					System.out.println();
	    				}*/
	    				
	    				String endTime =statusArray.get("endTime").textValue();
	    				if(startTime.length()==4){
	    					
	    					endTime="0"+endTime;
	    				}
	    				
	    				
	    				
	    				
	    				String startDateTime = date+" "+startTime;//1 pm PST
	    				String endDateTime = date+" "+endTime;
	    				
	    				
	    				
	    				
	    				ZonedDateTime startDateTimeZ = LocalDateTime.parse(startDateTime, formatter).atZone(ZoneId.of(AppStateConstants.ZONE));
	    				/*ZonedDateTime ldtStart=startDateTimeZ.with(LocalTime.MIN);
	    				if(!startDateTimeZ.isEqual(startDateTimeZ.with(LocalTime.MIN))){
	    					ldtStart = startDateTimeZ.withZoneSameInstant(ZoneId.of(tz));
	    				}*/
	    				ZonedDateTime ldtStart = startDateTimeZ.withZoneSameInstant(ZoneId.of(tz));//(dateTime, );
//	    			
	    				String startDateZoned = DateTimeFormatter.ofPattern(AppStateConstants.DATE_FORMAT).format(ldtStart);
//	    				System.out.println(startDateZoned);
	    				
	    				
	    				
	    				if(endTime.equalsIgnoreCase("N/A")){
	    					conditionType=0;
	    					}else{

	    					ZonedDateTime endDateTimeZ = LocalDateTime.parse(endDateTime, formatter).atZone(ZoneId.of(AppStateConstants.ZONE));
		    				ZonedDateTime ldtEnd = endDateTimeZ.withZoneSameInstant(ZoneId.of(tz));//(dateTime, );
		    				endDateZoned = ldtEnd.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		    				
		    				ldtEndString=ldtEnd.format(DateTimeFormatter.ofPattern("HH:mm"));
		    				if(!startDateZoned.equalsIgnoreCase(endDateZoned) && 
		    						!statusArray.get("status").toString().contains("Up")){
		    					conditionType=2;}
	    				}
	    				
	    				
	    				
	    				switch (conditionType)
	    				{
	    				// end date is N/A
	    				case 0:
	    					if(statusArray.get("status").toString().contains("Down")){
//		    					oneDot ="<a data-toggle='tooltip' title='"+ldtStart.toString() +" to " + "N/A" +", "+ statusArray.get("description").textValue()  +  statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue() +"'><img src='red.png'></a>";
//		    					oneDot ="<a data-toggle='tooltip' title='"+ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +"hrs to " + "N/A" +", "+ statusArray.get("description").textValue()  +  statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue() +"'><img src='Ared.png'></a>";
		    					oneDot=sendMeDot(ldtStart, "N/A", statusArray.get("description").textValue() , "Ared.png");
	    						//oneDot ="<a data-toggle='tooltip' title='"+ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "N/A" +" "+ statusArray.get("description").textValue() +"'><img src='Ared.png'></a>";

	    					}
		    				if(statusArray.get("status").toString().contains("Disrupted")){
//		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.toString() +" to " + "N/A" +", "+ statusArray.get("description").textValue() +  statusArray.get("startTime").textValue()+ " # "+statusArray.get("endTime").textValue() +"'><img src='orange.png'></a>";
//		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "N/A" +", "+ statusArray.get("description").textValue() +  statusArray.get("startTime").textValue()+ " # "+statusArray.get("endTime").textValue() +"'><img src='Borange.png'></a>";
		    				//	oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "N/A" +" "+ statusArray.get("description").textValue() +  "'><img src='Borange.png'></a>";

		    					oneDot=sendMeDot(ldtStart, "N/A", statusArray.get("description").textValue() , "Borange.png");

		    				}
		    				if(statusArray.get("status").toString().contains("Up")){
		    					oneDot = " ";
		    				}
		    				
		    				if(statusArray.get("status").toString().contains("Scheduled")){
// changes end time N/A to 23:59
//		    					oneDot=sendMeDot(ldtStart, "23:59", statusArray.get("description").textValue() , "Cpurple.png");
		    					
//		    					oneDot=sendMeDot(startTime, "23:59", statusArray.get("description").textValue() , "Cpurple.png");

		    					if(startTime.equals("00:00"))
		    					{
		    						if("N/A".equalsIgnoreCase(ldtEndString)){
				    					oneDot=sendMeDot("00:00", "23.59", statusArray.get("description").textValue() , "Cpurple.png");

		    						}else{
				    					oneDot=sendMeDot("00:00", ldtEndString, statusArray.get("description").textValue() , "Cpurple.png");
		    						}
		    						
		    					}else{
			    					oneDot=sendMeDot(ldtStart, "23:59", statusArray.get("description").textValue() , "Cpurple.png");
		    					}
		    				}
		    			
		    				Map.Entry<Integer, Integer> place = findMyPlace(startDateZoned , key, table, rowSize);
		    				table = placeInTable(table,oneDot, place.getKey(),place.getValue());
		    				
	    					break;
	    					
	    				// end date is same as Start Date
	    				case 1:
	    					if(statusArray.get("status").toString().contains("Down")){
//		    					oneDot ="<a data-toggle='tooltip' title='"+ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" to " + ldtEndString +", "+ statusArray.get("description").textValue() + statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue()+"'><img src='red.png'></a>";
//		    					oneDot ="<a data-toggle='tooltip' title='"+ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + ldtEndString +" hrs , "+ statusArray.get("description").textValue() + statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue()+"'><img src='Ared.png'></a>";
//		    					oneDot ="<a data-toggle='tooltip' title='"+ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + ldtEndString +" hrs "+ statusArray.get("description").textValue()+"'><img src='Ared.png'></a>";

		    					oneDot=sendMeDot(ldtStart, ldtEndString, statusArray.get("description").textValue() , "Ared.png");

	    						
	    					}
		    				if(statusArray.get("status").toString().contains("Disrupted")){
		    					
//		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" to " + ldtEndString +", "+ statusArray.get("description").textValue()  + statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue()+"'><img src='orange.png'></a>";
		    				
		    					/*oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + 
		    							ldtEndString +" hrs "+ statusArray.get("description").textValue() +"'><img src='Borange.png'></a>";
		    					*/
		    					
		    					oneDot=sendMeDot(ldtStart, ldtEndString, statusArray.get("description").textValue() , "Borange.png");

		    					
		    				}
		    				if(statusArray.get("status").toString().contains("Up")){
		    					oneDot = " ";
		    				}
		    				
		    				if(statusArray.get("status").toString().contains("Scheduled")){
		    					
		    					
		    					// if the issue starts in PST 00:00 in local also its should say PST timing
		    					if(startTime.equals("00:00"))
		    					{
			    					oneDot=sendMeDot("00:00", ldtEndString, statusArray.get("description").textValue() , "Cpurple.png");
		    					}else{
			    					oneDot=sendMeDot(ldtStart, ldtEndString, statusArray.get("description").textValue() , "Cpurple.png");
		    					}
		    					

		    				}
		    				
		    				Entry<Integer, Integer> place1 = findMyPlace(startDateZoned , key, table, rowSize);
		    				table = placeInTable(table,oneDot, place1.getKey(),place1.getValue());
		    				
		    				break;
		    				
	    				// end date is next date.
	    				case 2:
	    					
	    					if(statusArray.get("status").toString().contains("Down")){
//		    					oneDot ="<a data-toggle='tooltip' title='"+ldtStart.toString() +" to " + "23:59" +", "+ statusArray.get("description").textValue()  +  statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue()+"'><img src='red.png'></a>";
//		    					oneDot ="<a data-toggle='tooltip' title='"+ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" to " + "23:59" +", "+ statusArray.get("description").textValue()  +  statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue()+"'><img src='red.png'></a>";


//		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.toString() +" to " + "23:59" +", "+ statusArray.get("description").textValue()  + statusArray.get("startTime").textValue()+ " # "+statusArray.get("endTime").textValue() +"'><img src='orange.png'></a>";
//		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "23:59  hrs" +", "+ statusArray.get("description").textValue()  + statusArray.get("startTime").textValue()+ " # "+statusArray.get("endTime").textValue() +"'><img src='Ared.png'></a>";
		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "23:59 hrs" +" "+ statusArray.get("description").textValue()+"'><img src='Ared.png'></a>";
		    				//	oneDot=sendMeDot(ldtStart, "23:59 hrs", statusArray.get("description").textValue() , "Ared.png");

		    					
		    					Entry<Integer, Integer> place2 = findMyPlace(startDateZoned , key, table, rowSize);
			    				table = placeInTable(table,oneDot, place2.getKey(),place2.getValue());
			    				
//			    				oneDot = "<a data-toggle='tooltip' title='"+ "00:00" +" to " + ldtEndString +", "+ statusArray.get("description").textValue()  + statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue() +"'><img src='orange.png'></a>";
			    				oneDot = "<a data-toggle='tooltip' title='"+ "00:00 hrs" +" to " + ldtEndString +" hrs "+ statusArray.get("description").textValue() +"'><img src='Ared.png'></a>";
//		    					oneDot=sendMeDot(ldtStart, ldtEndString, statusArray.get("description").textValue() , "Ared.png");

			    				Entry<Integer, Integer> placeAdditionalDot = findMyPlace(endDateZoned , key, table, rowSize);
			    				table = placeInTable(table,oneDot, placeAdditionalDot.getKey(),placeAdditionalDot.getValue());
			    				
		    				
	    					
	    					}
	    					
		    				if(statusArray.get("status").toString().contains("Disrupted")){
//		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.toString() +" to " + "23:59" +", "+ statusArray.get("description").textValue()  + statusArray.get("startTime").textValue()+ " # "+statusArray.get("endTime").textValue() +"'><img src='orange.png'></a>";
		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "23:59 hrs" +" "+ statusArray.get("description").textValue() +"'><img src='Borange.png'></a>";
//		    					oneDot=sendMeDot(ldtStart, "23:59 hrs", statusArray.get("description").textValue() , "Borange.png");

		    					
		    					Entry<Integer, Integer> place2 = findMyPlace(startDateZoned , key, table, rowSize);
			    				table = placeInTable(table,oneDot, place2.getKey(),place2.getValue());
			    				
			    				
//			    				oneDot = "<a data-toggle='tooltip' title='"+ "00:00" +" to " + ldtEndString +", "+ statusArray.get("description").textValue()  + statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue() +"'><img src='orange.png'></a>";
			    				oneDot = "<a data-toggle='tooltip' title='"+ "00:00 hrs" +" to " + ldtEndString +" hrs "+ statusArray.get("description").textValue() +"'><img src='Borange.png'></a>";
//		    					oneDot=sendMeDot("00:00", ldtEndString, statusArray.get("description").textValue() , "Borange.png");

			    				Entry<Integer, Integer> placeAdditionalDot = findMyPlace(endDateZoned , key, table, rowSize);
			    				table = placeInTable(table,oneDot, placeAdditionalDot.getKey(),placeAdditionalDot.getValue());
			    				
		    				}
		    				
		    				if(statusArray.get("status").toString().contains("Scheduled")){
		    					
		    					if(startTime.equals("00:00"))
		    					{
			    					oneDot = "<a data-toggle='tooltip' title='"+ "00:00" +" hrs to " + "23:59 hrs" +" "+ statusArray.get("description").textValue() +"'><img src='Cpurple.png'></a>";
		    					}else{
			    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "23:59 hrs" +" "+ statusArray.get("description").textValue() +"'><img src='Cpurple.png'></a>";
		    					}
		    					
//		    					oneDot = "<a data-toggle='tooltip' title='"+ ldtStart.format(DateTimeFormatter.ofPattern("HH:mm")) +" hrs to " + "23:59 hrs" +" "+ statusArray.get("description").textValue() +"'><img src='Cpurple.png'></a>";

//		    					oneDot=sendMeDot(ldtStart, "23:59 hrs", statusArray.get("description").textValue() , "Cpurple.png");

		    					
		    					Entry<Integer, Integer> place2 = findMyPlace(startDateZoned , key, table, rowSize);
			    				table = placeInTable(table,oneDot, place2.getKey(),place2.getValue());
			    				
			    				
//			    				oneDot = "<a data-toggle='tooltip' title='"+ "00:00" +" to " + ldtEndString +", "+ statusArray.get("description").textValue()  + statusArray.get("startTime").textValue()+" # "+ statusArray.get("endTime").textValue() +"'><img src='orange.png'></a>";
			    				oneDot = "<a data-toggle='tooltip' title='"+ "00:00 hrs" +" to " + ldtEndString +" hrs "+ statusArray.get("description").textValue() +"'><img src='Cpurple.png'></a>";
		    					
//			    				ZonedDateTime startOfDay=startDateTimeZ.with(LocalTime.MIN);
//			    				oneDot=sendMeDot("00:00", ldtEndString, statusArray.get("description").textValue() , "Cpurple.png");

			    				Entry<Integer, Integer> placeAdditionalDot = findMyPlace(endDateZoned , key, table, rowSize);
			    				table = placeInTable(table,oneDot, placeAdditionalDot.getKey(),placeAdditionalDot.getValue());
			    				
		    				}
		    				
	    				break;	
	    				
	    				}
	    				
	    				
	    			
	    				
	    				
	    			return table;	
	    		
	    	
	}
		
	
	private String sendMeDot(ZonedDateTime ldtStartDot, String endTimeDot, String descriptionDot , String colorDot) {
		// TODO Auto-generated method stub
		String oneDot=" ";
		String startTime = ldtStartDot.format(DateTimeFormatter.ofPattern("HH:mm"));
		oneDot ="<a data-toggle='tooltip' title='"+startTime +" hrs to " + endTimeDot +" "+ descriptionDot +"'><img src='"+colorDot+"'></a>";
//		System.out.println("zoned "+oneDot);
		return oneDot;
	}
	
	private String sendMeDot(String ldtStartDot, String endTimeDot, String descriptionDot , String colorDot) {
		// TODO Auto-generated method stub
		String oneDot=" ";
		
		oneDot ="<a data-toggle='tooltip' title='"+ldtStartDot +" hrs to " + endTimeDot +" "+ descriptionDot +"'><img src='"+colorDot+"'></a>";
//		System.err.println("String "+oneDot);
		return oneDot;
	}


	private String[][] placeInTable(String[][] table, String oneDot, Integer row, Integer col) {
		// TODO Auto-generated method stub
		// put it 
		if(row !=0 && col !=0)
		{
			
			String cellValue = table[row][col];
			
			if(cellValue.trim().equalsIgnoreCase("N/A") )
			{
				table[row][col] = oneDot;
			}
			else
			{
				table[row][col]=table[row][col].concat(oneDot);
			}
			
			
		}
		else
		{
			System.out.println("oneDot "+ oneDot);
			System.err.println("Could not find a placement");
		}
		
		return table;
	}


	private String findEndTimeAccToTz(String tz) {
		// TODO Auto-generated method stub
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
		ZonedDateTime endMinute = LocalDateTime.parse("03:59", formatter).atZone(ZoneId.of(AppStateConstants.ZONE));
		
		return endMinute.format(DateTimeFormatter.ofPattern("HH:mm"));

	}


	private Entry<Integer, Integer> findMyPlace(String dateLocal, String key, String[][] table, Integer rowSize) {
		// TODO Auto-generated method stub
		
		
		int columnFound=0;
		int rowFound=0;
		// find the same value in table 
		for(int tableC =0 ; tableC < colSize ; tableC ++)
		{
			String curr = table[0][tableC].trim();
			//date = date.substring(1, date.length()-1);
//			System.out.println("table value at "+ tableC + " is "+ curr );
			if(curr.contains(dateLocal))
			{
				 columnFound = tableC;
			}
		}	
		for(int tableR=0; tableR < rowSize ; tableR++)
		{
			if(table[tableR][0].equalsIgnoreCase(key))
			{
				 rowFound = tableR;
			}
		}
//		System.out.println("My place "+ rowFound + " & "+ columnFound);
		Map.Entry<Integer,Integer> rowCol = new AbstractMap.SimpleEntry<Integer, Integer>(rowFound, columnFound);
		return rowCol;
		
	}


	//
	private String populateDaysStatusTz(JsonNode statusArray, int rowFound, int columnFound, String date, String tz) {
		
    	String statusInString = " ";
    		
//    			String dateL = date; 
    			
    			if(statusArray.get("status").toString().contains("Down"))
				{	//03-02-2018 3:00
    				
    				String startDate = date+" "+statusArray.get("startTime").textValue();
    				
    				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy hh:mm");
    				
//    				LocalDateTime now = LocalDateTime.now(ZoneId.of(AppStateConstants.ZONE));
    				ZonedDateTime dateTime = LocalDateTime.parse(startDate).atZone(ZoneId.of(tz));
    			  
//    				System.out.println(dateTime.toString());
    				
    				
    				
    			statusInString = statusInString+ "<a data-toggle='tooltip' title='"+statusArray.get("startTime").textValue() +" to " + statusArray.get("endTime").textValue() +"'><img src='Ared.png'></a>";
				}
    			if(statusArray.get("status").toString().contains("Disrupted"))
				{	
    			statusInString = statusInString+ "<a data-toggle='tooltip' title='"+statusArray.get("startTime").textValue() +" to " + statusArray.get("endTime").textValue() +"'><img src='Borange.png'></a>";
				}
		   
    	
    	
//    	item=statusInString;
    	return statusInString ;
    
	
}



	public String[][] addTodaysStatus(SearchResponse searchResponseToday, String[][] table, String tz) throws JsonProcessingException, IOException {
		// TODO Auto-generated method stub
		
		
				String output= searchResponseToday.toString();
				ObjectMapper mapper = new ObjectMapper();
				
				//---
				JsonNode response = mapper.readTree(output);
				
//				ZonedDateTime ldtDate = LocalDateTime.now().atZone(ZoneId.of(AppStateConstants.ZONE));
//				DateTimeFormatter formatterDate = DateTimeFormatter.ofPattern("dd-MM-yyyy");
//				String dateToday = ldtDate.format(formatterDate);
		    	
		       
				
				//---
				int noOfServersAgg = response.get("aggregations").get("serverAgg").get("buckets").size();
		    	
		        
		        
		     // if any status has end date as Default data, get the status and put it as current one.
//		        var currentStatus = [];//col
		        
		        for(int server = 0 ; server < noOfServersAgg ; server++)
		        	{
		        	
		        	String serverName = response.get("aggregations").get("serverAgg").get("buckets").get(server).get("key").asText();
		        		
		        	for(int tableRow = 0 ; tableRow < table.length ; tableRow++)
		        	{	String tableVal =table[tableRow][0].substring(1, table[tableRow][0].length()-1);
		        		if(tableVal.equalsIgnoreCase(serverName))
		        		{
		        			
		        			
		                	String serverWithCurrStatus = "<img src='Dgreen.png'>"+serverName;
		                	
		    				JsonNode statusArray =response.get("aggregations").get("serverAgg").get("buckets").get(server).get("nestedDateAgg").get("buckets").get(0).get("getDocs").get("hits").get("hits").get(0).get("_source").get("status");

			        		for (int stausHit = 0 ; stausHit < statusArray.size(); stausHit++) {

			        			String statusTem = response.get("aggregations").get("serverAgg").get("buckets").get(server).get("nestedDateAgg").get("buckets").get(0).get("getDocs").get("hits").get("hits").get(0).get("_source").get("status").get(stausHit).get("status").asText();//(innerCounter)
			        			String statusET = response.get("aggregations").get("serverAgg").get("buckets").get(server).get("nestedDateAgg").get("buckets").get(0).get("getDocs").get("hits").get("hits").get(0).get("_source").get("status").get(stausHit).get("endTime").asText();//(innerCounter)

			        			
			        			if(statusTem.equals("Down") && statusET.equals("N/A"))
			        	    	{
			        	    		serverWithCurrStatus=serverWithCurrStatus.replace("Dgreen", "Ared");
//			        	    		System.out.println(serverWithCurrStatus);
			        	    	}
			        			if(statusTem.equals("Disrupted") && statusET.equals("N/A"))
			        			{
			        				serverWithCurrStatus=serverWithCurrStatus.replace("Dgreen", "Borange");
			        			}
			        			
			        			
			        			if(statusTem.equals("Scheduled"))
			        			{
			        				
			        				if(!statusET.equals("N/A") && statusET.matches("\\d\\d:\\d\\d") ){
			        					String date = response.get("aggregations").get("serverAgg").get("buckets").get(server).get("nestedDateAgg").get("buckets").get(0).get("getDocs").get("hits").get("hits").get(0).get("_source").get("date").asText();//(innerCounter)

				        				statusET=statusET.replace("\\s", "");
				        				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");

//				        				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm");
					        			LocalDateTime ldtStatusET = LocalDateTime.parse(date+" "+statusET, formatter);
					        			ZonedDateTime zonedStatusET=ldtStatusET.atZone(ZoneId.of(AppStateConstants.ZONE));
					        			zonedStatusET = zonedStatusET.withZoneSameInstant(ZoneId.of(tz));
					     				ZonedDateTime zonedNowDateTime = ZonedDateTime.ofInstant(Instant.now(), ZoneId.of(tz));
					     				
					     				
					     				if(zonedNowDateTime.isBefore(zonedStatusET))
					     				{
					        				serverWithCurrStatus=serverWithCurrStatus.replace("Dgreen", "Cpurple");

					     				}

			        				}
			        				
			        				if(statusET.equals("N/A"))
			        				{
				        				serverWithCurrStatus=serverWithCurrStatus.replace("Dgreen", "Cpurple");

			        				}
				        			
				     				
				        			
				        				
				        			}
				        			
				        		}
			        			table[tableRow][0]="\""+serverWithCurrStatus+"\"";

			        		}
			        			
			        			
		        		}
		        	}
		        	
		        
//		        String[][] tableNew = new String[table.length-1][8] ;
		        table = Arrays.copyOfRange(table, 1 , table.length);
		        
			    Arrays.sort(table, (a, b) -> String.CASE_INSENSITIVE_ORDER.compare(a[0], b[0]));
			    
			    
			    
//			    System.arraycopy(table, 0, tableNew, 21, length);
		        
//			    Collections.reverse(Arrays.asList(table));
		        
		       /* for(int i =1 ; i< table.length; i++)
		        {
		        	for(int j=0;j<table[i].length;j++)
		        	{
		        		tableNew[i-1][j]= table[i][j];
		        	}
		        }*/
		        
		        
		        return table;
	}
		    

//	@SuppressWarnings("deprecation")//
	public ArrayList<String> changeDateFormat(ArrayList<String> dates) throws ParseException {
		// TODO Auto-generated method stub
		
		DateFormat sdf = new SimpleDateFormat("dd-MM-YYYY ");
		SimpleDateFormat sdfMonth = new SimpleDateFormat("dd-MMM-YYYY");

		for(int i=1;i<dates.size();i++)
		{
			String date = dates.get(i).substring(1, dates.get(i).length()-1);
			//String d = sdf.format(date.toString());
//			System.out.println(date);
//			java.util.Date d =sdf.parse(date);
//			System.out.println(d);
			DateFormat df = new SimpleDateFormat("dd-MM-yyyy");
			date.toString();
	       
			 java.util.Date today = df.parse(date.toString());
//	            System.out.println("Today = " + sdfMonth.format(today));
	        
	        /*
			Date newDate =(Date) sdf.parse(date);
			String newD =sdfMonth.format(newDate);*/

	         dates.set(i, "\""+sdfMonth.format(today)+"\"");
//			System.out.println(today);
//			dates.add(i, "\""+today+"\"");
		}
		
		return dates;
	}


	public JsonNode aggregateAppData(String app) throws JsonProcessingException, IOException {
	
		
		String query = utilities.formAggreagtionQuery(app);
		// fire query and get the JSON back.
		
		
		Client esClient = getTransportClient();
    	SearchResponse searchResponse = esClient.prepareSearch(AppStateConstants.INDEX).setTypes(AppStateConstants.TYPE).setSource(query).execute()
				.actionGet();
    
    	String output= searchResponse.toString();
		ObjectMapper mapper = new ObjectMapper();
		
		JsonNode response = mapper.readTree(output);
		
    	JsonNode jsonNode = response.get("aggregations").get("status").get("group_by_state").get("buckets");
    	
    	return jsonNode;
		
	}


	public List<List<String>> splitInto2Table(String[][] table, Boolean type) {
				 
		 // from uninterrupted find ones with : 
			List<List<String>> parentAndChild = Arrays.stream(table)
	                .map(Arrays::asList).filter(hasChild())
	                .collect(Collectors.toList());
			
		
			List<List<String>> onlyParents = Arrays.stream(table)
	                .map(Arrays::asList).filter(hasChild().negate())
	                .collect(Collectors.toList());
		
			
			
			List<List<String>> onlyInterrupted = Arrays.stream(table)
	                .map(Arrays::asList).filter(isUp().negate())
	                .collect(Collectors.toList());
			
			
			// down parents should not appear in interrupted and in Parents only
			onlyParents.removeAll(onlyInterrupted);
			

		
//			System.out.println("list Interrupted "+ onlyInterrupted.size() );
//			printTable(onlyInterrupted);
			
		 
			// make the parents row empty
			for(int row = 0 ; row < parentAndChild.toArray().length; row++)
			{
				List<String> rowValue = parentAndChild.get(row);
				String[] zerothValue = rowValue.get(0).split(":");
				String app = zerothValue[0];
				
				// changing all the parent status to child so that we have unique parent names.
				app = app.replace("Dgreen", "child");
				app = app.replace("Ared", "child");
				app = app.replace("Borange", "child");
				app = app.replace("Cpurple", "child");
				app = app.replace(">", "> ");
				app=app+" \"";
				
				app = app.replace("<", "<span class='getChildNodes'> <");
				
				app = app.replaceAll("\\s\"", "</span> \"");

			
				String[] defaultValues = new String[8];
				Arrays.fill(defaultValues, "\" \" ");
				List<String> defaultList = Arrays.asList(defaultValues);
				
				defaultList.set(0, app);
				parentAndChild.set(row,defaultList );
				
			}
			
			
		//	System.out.println("Child call defualt  "+ Arrays.deepToString(parentAndChild.toArray()));
			
			// finding distint
			parentAndChild = parentAndChild.stream().distinct().collect(Collectors.toList());
		

//			System.out.println("list Only Parents with default values "+ onlyParents.size() );
//			printTable(onlyParents);
			
			// we have 3 tables only duplicate interrupted duplicate is an issue. 
			onlyInterrupted.addAll(onlyParents);
			onlyInterrupted.addAll(parentAndChild);
			
			
//			onlyParents.addAll(parentAndChild);
//			System.out.println("final table " );
//			printTable(onlyInterrupted);
		
//	return onlyInterrupted.toArray();
			
			return onlyInterrupted;

	}
	
	
	
	public static Predicate<? super List<String>> hasChild() {
	    return p -> p.get(0).contains(":");
	}
	
	public static Predicate<? super List<String>> hasNoChild() {
	    return p -> !p.get(0).contains(":");
	}
	
	public static Predicate<? super List<String>> isUp() {
	    return p -> p.get(0).contains("<img src='Dgreen.png'>");
	}

	public String[][] convertJsonTo2D(JsonNode aggsData) {
		
		
		// find the size
		// iterate the size
		// for each element put in one array of 2 d array.
		Integer size = aggsData.size();
		// remove N/A row
		
		
		
		String[][] aggs2D=new String[size][2];
		for(int row = 0; row < size; row++)
		{
				 String tempKey = aggsData.get(row).get("key").asText();
				 if("N/A".equalsIgnoreCase(tempKey))
				 {
					 tempKey="ZzonedOut";
				 }
				 aggs2D[row][0]="\""+tempKey+"\"";
				 aggs2D[row][1]="\""+aggsData.get(row).get("doc_count").asText()+"\"";
			
			 
		 
		}
	    Arrays.sort(aggs2D, (a, b) -> String.CASE_INSENSITIVE_ORDER.compare(a[0], b[0]));

		String[][] table2DWithoutNA = Arrays.copyOfRange(aggs2D, 0 , aggs2D.length-1);
				
		return table2DWithoutNA;
		
	}
	
	@Autowired
	private RestTemplate restTemplate;
	
	public String getChild(String app, String date, String tz) {

		// do rest call to search response search again
		final String url = "http://localhost:2222/status/searchRes";
		URI uri = URI.create(url+"?date="+date+"&tz="+tz);
		String result = restTemplate.getForObject(uri, String.class);

		System.out.println("result : "+ result);
	      
		// filter results as pers app name
		//filterByApp(result);
		
		// return string
		return result.toString();
	}


	List<List<String>> filterByApp(String[][] table, String app) {

		
		List<List<String>> list = Arrays.stream(table)
                .map(Arrays::asList).filter(isAdultMale(app.trim()))
                .collect(Collectors.toList());
		
	
		
		
		getOnlyChild(list);
		
		
/*System.out.println("list size after filtering by app name "+ list.size());
		
		System.out.println("original table ");
		printTable(Arrays.stream(table)
                .map(Arrays::asList)
                .collect(Collectors.toList()));
		
		System.out.println("filteres with app name "+ app);
		printTable(list);
		
		System.out.println("only child ");
		printTable(list);
		*/
		
		return list;
		
		
	}
	
	private void getOnlyChild(List<List<String>> list) {
		// TODO Auto-generated method stub
		for(int row = 0 ; row < list.toArray().length; row++)
		{
			List<String> rowValue = list.get(row);
			
			String appCh = rowValue.get(0);
			
			appCh.indexOf(">");
			String parent = appCh.substring(appCh.indexOf(">")+1, appCh.indexOf(":"));
			String child = appCh.replace(parent.trim(), "");
			child = child.replace(":", "");
			child=child.replace("<", " <");//)("\"", replacement)
			list.get(row).set(0, child);
		}
	}


	public static Predicate<? super List<String>> isAdultMale(String app) {
	    return p -> p.get(0).contains(app);
	}


	public void makeParents(String[][] table) {

		List<List<String>> list = Arrays.stream(table)
                .map(Arrays::asList)
                .collect(Collectors.toList());
		
		
		/*for(int row=0; row < list.size(); row++)
		{
			String app = list.get(row).get(0);
			app.split("")
		}*/
	}


	public void formFinalView(String[][] table) throws JsonGenerationException, JsonMappingException, IOException {
		List<List<String>> list = Arrays.stream(table)
                .map(Arrays::asList)
                .collect(Collectors.toList());
		
		
		final ByteArrayOutputStream out = new ByteArrayOutputStream();
	    final ObjectMapper mapper = new ObjectMapper();
	    
	    mapper.writeValue(out, table);

	    final byte[] data = out.toByteArray();
	}


	public List<List<String>> joinParentsWithChildren(List<List<String>> initialTable, List<List<String>> child, String app) {

		
		System.out.println("app name "+ app);
		String[] apps=app.split(":");
		System.out.println("Parent name->"+ apps[0]);
		
		String parentApp = apps[0].trim();
		
		Integer foundAt = null;
		
		for(int row=0; row < initialTable.toArray().length ; row++)
		{
			List<String> rowValue = initialTable.get(row);
//			System.out.println(rowValue.get(0));
			if(rowValue.get(0).contains(parentApp)){
			System.out.println("found at row "+ row);
			foundAt=row;
			break;
			}
		}
		 
		if(null !=foundAt){

			System.out.println("Found at "+ foundAt);
		}else
		{
			System.err.println("NOT FOUND");
		}
		
		
		System.out.println(" Add the tables ");
		
		
		// insert the child nodes here 
		if(!child.isEmpty() && null != foundAt ){
			
			// replace the right arrow with down one.
			String a = initialTable.get(foundAt).get(0).replace("child", "downarrow");
			initialTable.get(foundAt).set(0, a);
			
			initialTable.addAll(foundAt+1, child);
		}
		
		/*System.out.println("*******FINAL TABLE *******");
		printTable(initialTable);*/
		
		
		
		return initialTable;
	}

	

/*	public void printTable(List<List<String>> initialTable){
		for(int row=0; row < initialTable.toArray().length ; row++)
		{
			List<String> rowValue = initialTable.get(row);
			System.out.println("row "+row+ " value "+rowValue.get(0));
			if(rowValue.get(0).contains("".trim())){
			System.out.println("found at row "+ row);	
			}
		}
		
		System.out.println("");
		
		
	}*/


	public String[][] addAggsUrlInDot(String[][] table, HttpServletRequest request) {

		String urlIn = formUrl(request);

		
		
		// find app name.
		for(int row =0  ; row < table.length ; row ++)
		{	
			/*String uri = requestURL. */
			String url = urlIn+"/status/aggs?app=";
			
			String appName = table[row][0];
			appName = appName.substring(appName.indexOf(">")+1, appName.length()-1);
			
			url=url+appName;
			
			for( int col = 1 ; col < 7; col ++)
			{
				String val =  table[row][col];
				if(val.contains("data-toggle"))
				{
					val = val.replace("<a", "<a href='"+url+ "' target='_blank' " );
					
					table[row][col]=val;
				}
			}
			
			
		}
	
		
		
	return table;
	}


	public String formUrl(HttpServletRequest req) {

		
		 String scheme = req.getScheme();             // http
		 String serverName = req.getServerName();     // hostname.com
		 int serverPort = req.getServerPort(); 
		 
		 //"http://localhost:2222/status/aggs?app=";
		 return scheme+"://"+serverName+":"+serverPort;
	}


}


	

