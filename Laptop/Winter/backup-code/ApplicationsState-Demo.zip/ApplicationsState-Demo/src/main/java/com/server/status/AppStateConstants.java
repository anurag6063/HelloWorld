package com.server.status;

import java.text.SimpleDateFormat;
import java.util.Date;

public class AppStateConstants {

	
	public static final String CLUSTER = "elasticsearch";
	public static final String LOCALHOST  = "10.85.17.177";//135.36.0.89
	public static final Integer PORT = 9300;
	
	// 123 has unnested good data
	public static final String INDEX  ="standalonetest500";//standalonetest112 - UNIX ; standalonetest121 was with normal DC v1
	public static final String TYPE  ="teststatus";
	public static final String DATE_FORMAT  ="dd-MM-yyyy";
	public static final String ZONE  = "America/Los_Angeles";

	
 private static final SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
	 
	 
	 public static final String DATE =  getTodaydate();
	 public static String getTodaydate()
	 {
		 return  dateFormat.format(new Date());	

	 }

	
}
