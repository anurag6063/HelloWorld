package com.server.status;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.elasticsearch.action.search.SearchResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;

@Controller
public class StatusController {

	@Autowired
	Service service;

	@RequestMapping("/status")
	public ModelAndView showStatusJava(Model model,
			@RequestParam(value = "date", required = false, defaultValue = "0") String date,
			@RequestParam(value = "tz", required = false, defaultValue = "America/Los_Angeles") String tz,
			HttpServletRequest request
			)
			throws ParseException, IOException {

		System.out.println("date passed: " + date);
		System.out.println("tz passed: " + tz);

		ModelAndView mav = new ModelAndView("statusJava");

		int start = service.findDateRange(date, tz); // +2
		ArrayList<String> dates = service.dateInHeaderJava8(start, tz);

		// get data in required flip.
		SearchResponse searchResponse = service.searching(dates.get(1), dates.get(7));

		// here the data
		String[][] table = service.searchResMixed(searchResponse, start, tz);

//		service.makeParents(table);
		
		ArrayList<String> datesToday = service.dateInHeaderJava8(0, "America/Los_Angeles");
		SearchResponse searchResponseToday = service.searching(datesToday.get(1), datesToday.get(1));
		
		table = service.addTodaysStatus(searchResponseToday, table, tz);
// end of original display and TD structure.
		
		// adding href where we have dot in status.
		table = service.addAggsUrlInDot(table, request);
		
		
		List<List<String>> tableInturrupted = service.splitInto2Table(table, false);
		
	    
	    /*if(null == tableInturrupted ) {
	    String [][] noDataTable = { {
	    "\"All Serives are Up and Running currently\""}
	    };
	  
	  tableInturrupted = noDataTable; }*/

		mav.addObject("headers", service.changeDateFormat(dates));

		mav.addObject("response", Arrays.deepToString(tableInturrupted.toArray()));
//		mav.addObject("response", data);


		return mav;

	}

	

	@ResponseBody
	@RequestMapping(value = "/status/child", method = RequestMethod.GET)
	public String getChild(@RequestParam(value = "app", required = true) String app,
			@RequestParam(value = "date", required = false, defaultValue = "0") String date,
			@RequestParam(value = "tz", required = false, defaultValue = "America/Los_Angeles") String tz,
			HttpServletRequest request
			
			)throws ParseException, JsonProcessingException, IOException 
	{

		long startMethod = System.currentTimeMillis();
		System.out.println("data passed is " + tz + " app "+app );
		
		
		int start = service.findDateRange(date, tz);
		ArrayList<String> dates = service.dateInHeaderJava8(start, tz);

		SearchResponse searchResponse = service.searching(dates.get(1), dates.get(7));
		String[][] table = service.searchResMixed(searchResponse, start, tz);

		ArrayList<String> datesToday = service.dateInHeaderJava8(0, "America/Los_Angeles");
		SearchResponse searchResponseToday = service.searching(datesToday.get(1), datesToday.get(1));
		
		String[][] tableSearchRes = service.addTodaysStatus(searchResponseToday, table, tz);

		List<List<String>> finalTable = service.splitInto2Table(tableSearchRes, false);

		// adding href where we have dot in status.
		table = service.addAggsUrlInDot(table, request);
				
		// normal table formed
		
//		 will get only children
		List<List<String>> child= service.filterByApp(table, app.trim());
		
		// add initial table and this child at exact location.
		
		// initial table
		/*System.out.println("INITAIL TABLE");
		service.printTable(finalTable);
		
		System.out.println("CHILD TABLE");
		service.printTable(child);*/

		
		List<List<String>> tableWithChildAtLoc = service.joinParentsWithChildren(finalTable, child, app);
		
		
		System.err.println("Time Taken: "+(System.currentTimeMillis()-startMethod));
		return Arrays.deepToString(tableWithChildAtLoc.toArray());
	}
	
	
	@ResponseBody
	@RequestMapping(value = "/status/header", method = RequestMethod.GET)
	public String getHeaders(@RequestParam(value = "date", required = false, defaultValue = "0") String date,
			@RequestParam(value = "tz", required = false, defaultValue = "America/Los_Angeles") String tz)
			throws ParseException {

		int start = service.findDateRange(date, tz);
		ArrayList<String> dates = service.dateInHeaderJava8(start, tz);

		return service.changeDateFormat(dates).toString();
	}

	@ResponseBody
	@RequestMapping(value = "/status/searchRes", method = RequestMethod.GET)
	public String getSearchResponse(@RequestParam(value = "date", required = false, defaultValue = "0") String date,
			@RequestParam(value = "tz", required = false, defaultValue = "America/Los_Angeles") String tz,
			HttpServletRequest request)
			throws ParseException, JsonProcessingException, IOException {
		long startMethod= System.currentTimeMillis();
		System.out.println("time zone passed is " + tz);
		int start = service.findDateRange(date, tz);
		ArrayList<String> dates = service.dateInHeaderJava8(start, tz);

		SearchResponse searchResponse = service.searching(dates.get(1), dates.get(7));
		String[][] table = service.searchResMixed(searchResponse, start, tz);

		ArrayList<String> datesToday = service.dateInHeaderJava8(0, "America/Los_Angeles");
		SearchResponse searchResponseToday = service.searching(datesToday.get(1), datesToday.get(1));
		
		table = service.addTodaysStatus(searchResponseToday, table, tz);
		// adding href where we have dot in status.
		table = service.addAggsUrlInDot(table, request);
		
		
		List<List<String>> tableInturrupted = service.splitInto2Table(table, false);

		System.err.println("Time Taken: "+(System.currentTimeMillis()-startMethod));

		return Arrays.deepToString(tableInturrupted.toArray());
		
		

	}

	@RequestMapping(value = "/status/aggs", method = RequestMethod.GET)
	public ModelAndView getAgg(@RequestParam(value = "app", required = true) String app)
			throws ParseException, JsonProcessingException, IOException {

		System.out.println("Application name passed is " + app);
		ModelAndView mav = new ModelAndView("aggregatedData");

		JsonNode aggsData = service.aggregateAppData(app);

		String[][] data2D = service.convertJsonTo2D(aggsData);

		System.out.println(Arrays.deepToString(data2D));

		 mav.addObject("dataTable", Arrays.deepToString(data2D));
		 mav.addObject("app",app);

		 

		// mav.addObject("dataTable","[[\"Services - Wireless ~ US-Pacific
		// Region\", \" \", \" \", \" \", \" \", \" \", \" \", \"
		// \"],[\"Services - Wireless ~ US-Mountain Region\", \" \", \" \", \"
		// \", \" \", \" \", \" \", \" \"], [\"Services - Wireless ~ US-East
		// Region\", \" \", \" \", \" \", \" \", \" \", \" \", \" \"]]");

		/*mav.addObject("dataTable",
				"[[\"Services - Wireless ~ US-Pacific Region\", \" \", \" \", \" \", \" \", \" \", \" \", [\"Services - Wireless ~ US-Mountain Region\", \" \", \" \", \" \", \" \", \" \", \" \", \" \"]],[\"Services - Wireless ~ US-East Region\", \" \", \" \", \" \", \" \", \" \", \" \", \" \"]]");
*/
		return mav;
	}


}
