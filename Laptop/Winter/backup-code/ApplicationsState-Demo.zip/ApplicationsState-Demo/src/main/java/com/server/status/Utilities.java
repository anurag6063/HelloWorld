package com.server.status;

import org.springframework.stereotype.Component;

@Component
public class Utilities {

	
	public String getQuery(String startDate , String endDate) {
		
		/*String end = start==0 ? "-0" : String.valueOf(start);
		String.valueOf(start);*/
		
//		String query = "{\"query\":{\"match_all\":{}}}";// match all query
		
		String query = " { \"size\": 0, \"query\": { \"range\" : {  \"date\" : {  \"gte\" :"+endDate+",\"lte\":"+startDate+" } } }, \"aggs\" : { \"serverAgg\" : { \"terms\": {  \"field\": \"application\", \"size\": 500, \"order\": { \"_count\": \"desc\" } } , \"aggs\": { \"nestedDateAgg\":{ \"date_histogram\" : { \"field\" : \"date\", \"interval\" : \"1D\", \"format\" : \"dd-MM-yyyy\" , \"order\": { \"_key\": \"dsc\" }}, \"aggs\": { \"getDocs\": { \"top_hits\": { \"size\": 10 } } } } } } } } ";
		
//		String query = "{     \"size\":0,   \"query\":{        \"range\":{           \"date\":{              \"gte\":\"now-8d/d\",            \"lte\":\"now-0d/d\"         }      }   },   \"aggs\":{        \"serverAgg\":{           \"terms\":{              \"field\":\"application\",            \"size\":10,            \"order\":{                 \"_count\":\"desc\"            }         },         \"aggs\":{              \"nestedDateAgg\":{                 \"date_histogram\":{                    \"field\":\"date\",                  \"interval\":\"1D\",                  \"format\":\"dd-MM-yyyy\",                  \"order\":{                       \"_key\":\"asc\"                  }               },               \"aggs\":{                    \"getDocs\":{                       \"top_hits\":{                          \"size\":10                     }                  }               }            }         }      }   }}";
				
			
		
//		System.out.println(query);
		
		return query;
	}

	public String formAggreagtionQuery(String app) {
		
	/*	String query = "{" +
				"  \"size\": 0," +
				"  \"query\":{" +
				"  	\"term\": {" +
				"  		\"application\": \""+app+"\"" +
				"  	}" +
				"  }," +
				"  \"aggs\": {" +
				"    \"group_by_desc\": {" +
				"      \"terms\": {" +
				"        \"field\": \"status.description\"" +
				"      }" +
				"    }" +
				"  }" +
				"}";
		*/
		

String query = "{" +
"  \"size\": 0," +
"  \"query\":{" +
"  	\"bool\":{" +
"  		\"must\": {" +
"  			\"term\": {" +
"  		\"application\": \""+app+"\"" +
"  	}" +
"  		}" +
"  	}" +
"  	" +
"  }," +
"\"aggs\": {" +
"	\"status\": {" +
"		\"nested\":{" +
"					\"path\": \"status\"" +
"		}," +
"	  \"aggs\": {" +
"    \"group_by_state\": {" +
"      \"terms\": {" +
"        \"field\": \"status.description\"" +
"      }" +
"    }" +
"  }" +
"	}" +
"}" +
"}";
					
		System.out.println(query);
		return query;
	}
}
