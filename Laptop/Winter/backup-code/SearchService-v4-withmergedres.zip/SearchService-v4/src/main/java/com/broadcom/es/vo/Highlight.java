
package com.broadcom.es.vo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "filename",
    "doc_number",
    "docfile_name",
    "content_box",
    "summary",
    "description",
    "comments"
})
public class Highlight {

    @JsonProperty("filename")
    private List<String> filename = null;
    @JsonProperty("doc_number")
    private List<String> docNumber = null;
    @JsonProperty("docfile_name")
    private List<String> docfileName = null;
    @JsonProperty("content_box")
    private List<String> contentBox = null;
    @JsonProperty("summary")
    private List<String> summary = null;
    @JsonProperty("description")
    private List<String> description = null;
    @JsonProperty("comments")
    private List<String> comments = null;

    @JsonProperty("filename")
    public List<String> getFilename() {
        return filename;
    }

    @JsonProperty("filename")
    public void setFilename(List<String> filename) {
        this.filename = filename;
    }

    @JsonProperty("doc_number")
    public List<String> getDocNumber() {
        return docNumber;
    }

    @JsonProperty("doc_number")
    public void setDocNumber(List<String> docNumber) {
        this.docNumber = docNumber;
    }

    @JsonProperty("docfile_name")
    public List<String> getDocfileName() {
        return docfileName;
    }

    @JsonProperty("docfile_name")
    public void setDocfileName(List<String> docfileName) {
        this.docfileName = docfileName;
    }

    @JsonProperty("content_box")
    public List<String> getContentBox() {
        return contentBox;
    }

    @JsonProperty("content_box")
    public void setContentBox(List<String> contentBox) {
        this.contentBox = contentBox;
    }

    @JsonProperty("summary")
    public List<String> getSummary() {
        return summary;
    }

    @JsonProperty("summary")
    public void setSummary(List<String> summary) {
        this.summary = summary;
    }

    @JsonProperty("description")
    public List<String> getDescription() {
        return description;
    }

    @JsonProperty("description")
    public void setDescription(List<String> description) {
        this.description = description;
    }

    @JsonProperty("comments")
    public List<String> getComments() {
        return comments;
    }

    @JsonProperty("comments")
    public void setComments(List<String> comments) {
        this.comments = comments;
    }

	@Override
	public String toString() {
		return "Highlight [filename=" + filename + ", docNumber=" + docNumber + ", docfileName=" + docfileName
				+ ", contentBox=" + contentBox + ", summary=" + summary + ", description=" + description + ", comments="
				+ comments + "]";
	}

}
