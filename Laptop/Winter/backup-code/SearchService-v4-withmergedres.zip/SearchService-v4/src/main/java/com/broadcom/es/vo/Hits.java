
package com.broadcom.es.vo;

import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "total",
    "max_score",
    "hits"
})
public class Hits {

    @JsonProperty("total")
    private Integer total;
    @JsonProperty("max_score")
    private Double maxScore;
    @JsonProperty("hits")
//    private List<Hit> hits = null;
    private List<Map<String,Object>> hits = null;
    
    @JsonProperty("total")
    public Integer getTotal() {
        return total;
    }

    @JsonProperty("total")
    public void setTotal(Integer total) {
        this.total = total;
    }

    @JsonProperty("max_score")
    public Double getMaxScore() {
        return maxScore;
    }

    @JsonProperty("max_score")
    public void setMaxScore(Double maxScore) {
        this.maxScore = maxScore;
    }
    
    
    
    /*@JsonProperty("hits")
    public List<Hit> getHits() {
        return hits;
    }

    @JsonProperty("hits")
    public void setHits(List<Hit> hits) {
        this.hits = hits;
    }*/

    
    
	@Override
	public String toString() {
		return "Hits [total=" + total + ", maxScore=" + maxScore + ", hits=" + hits + "]";
	}
	
    @JsonProperty("hits")
	public List<Map<String, Object>> getHits() {
		return hits;
	}
    
    @JsonProperty("hits")
	public void setHits(List<Map<String, Object>> hits) {
		this.hits = hits;
	}
    
}
