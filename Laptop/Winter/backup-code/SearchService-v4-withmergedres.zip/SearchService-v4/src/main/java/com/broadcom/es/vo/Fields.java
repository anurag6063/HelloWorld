
package com.broadcom.es.vo;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "link",
    "box_file_id.keyword",
    "title",
    "tags"
})
public class Fields {

    @JsonProperty("link")
    private List<String> link = null;
    @JsonProperty("box_file_id.keyword")
    private List<String> boxFileIdKeyword = null;
    @JsonProperty("title")
    private List<String> title = null;
    @JsonProperty("tags")
    private List<String> tags = null;

    @JsonProperty("link")
    public List<String> getLink() {
        return link;
    }

    @JsonProperty("link")
    public void setLink(List<String> link) {
        this.link = link;
    }

    @JsonProperty("box_file_id.keyword")
    public List<String> getBoxFileIdKeyword() {
        return boxFileIdKeyword;
    }

    @JsonProperty("box_file_id.keyword")
    public void setBoxFileIdKeyword(List<String> boxFileIdKeyword) {
        this.boxFileIdKeyword = boxFileIdKeyword;
    }

    @JsonProperty("title")
    public List<String> getTitle() {
        return title;
    }

    @JsonProperty("title")
    public void setTitle(List<String> title) {
        this.title = title;
    }

    @JsonProperty("tags")
    public List<String> getTags() {
        return tags;
    }

    @JsonProperty("tags")
    public void setTags(List<String> tags) {
        this.tags = tags;
    }

	@Override
	public String toString() {
		return "Fields [link=" + link + ", boxFileIdKeyword=" + boxFileIdKeyword + ", title=" + title + ", tags=" + tags
				+ "]";
	}

}
