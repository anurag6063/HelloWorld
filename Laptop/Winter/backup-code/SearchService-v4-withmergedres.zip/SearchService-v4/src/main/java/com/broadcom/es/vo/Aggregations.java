/*
package com.broadcom.es.vo;

import java.util.Map;

import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Product",
    "Document Types",
    "Product Groups"
})
public class Aggregations {
	
	
    @JsonProperty("Product")
	Map<String,Object> aggsP = null;
    
    @JsonProperty("Document Types")
	Map<String,Object> aggsD = null;
    
	

    @JsonProperty("Product")
    private Product product;
    @JsonProperty("Document Types")
    private DocumentTypes documentTypes;
    @JsonProperty("Product Groups")
    private ProductGroups productGroups;

    @JsonProperty("Product")
    public Product getProduct() {
        return product;
    }

    @JsonProperty("Product")
    public void setProduct(Product product) {
        this.product = product;
    }

    @JsonProperty("Document Types")
    public DocumentTypes getDocumentTypes() {
        return documentTypes;
    }

    @JsonProperty("Document Types")
    public void setDocumentTypes(DocumentTypes documentTypes) {
        this.documentTypes = documentTypes;
    }

    @JsonProperty("Product Groups")
    public ProductGroups getProductGroups() {
        return productGroups;
    }

    @JsonProperty("Product Groups")
    public void setProductGroups(ProductGroups productGroups) {
        this.productGroups = productGroups;
    }

}
*/