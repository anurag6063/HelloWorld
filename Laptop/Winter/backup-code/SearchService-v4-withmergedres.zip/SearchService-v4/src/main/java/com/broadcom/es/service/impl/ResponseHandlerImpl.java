package com.broadcom.es.service.impl;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.broadcom.es.vo.EsSearchResponse;
import com.broadcom.es.vo.Response;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ResponseHandlerImpl {

	ObjectMapper mapper = new ObjectMapper();
	Logger log = LoggerFactory.getLogger(this.getClass());

	public Response formatResponse(EsSearchResponse response) throws IOException {

		log.info("from response handler");

		Response mergedResponse = new Response();
		BeanUtils.copyProperties(response.getResponses().get(0), mergedResponse);
		
		// merging aggs
		Map<String, Object> docAgg = response.getResponses().get(0).getAggregations();
		Map<String, Object> casesAgg = response.getResponses().get(1).getAggregations();

		// docAgg ie the leftside has all the buskets now.
		docAgg.putAll(casesAgg);
		mergedResponse.getAggregations().putAll(docAgg);

		
		/*
		log.info(docAgg.toString());
		response.getResponses().get(0).setAggregations(casesAgg);

		log.info(response.getResponses().get(0).toString());
*/

/*		BeanUtils.copyProperties(response.getResponses().get(1), response2);
		BeanUtils.copyProperties(response.getResponses().get(0), response2);
*/
		
		// merging Hits:
		List<Map<String, Object>> response3 = response.getResponses().get(0).getHits().getHits();
		List<Map<String, Object>> response4 = response.getResponses().get(1).getHits().getHits();

		List<Map<String, Object>> newList = Stream.concat(response3.stream(), response4.stream())
				.collect(Collectors.toList());

		response3.addAll(response4);
		
		mergedResponse.getHits().setHits((newList));
		
		// response3.putAll(response4);
		/*mapper.writeValueAsString(newList);
		mapper.writeValueAsString(response4);

		// trying map approach

		log.info(response.getResponses().get(0).toString());
*/
		// mapper.writeValueAsString(response2)
		/*
		 * JsonNode responseJsnNd = mapper.readTree(response); ObjectNode
		 * responseObjNd = ((ObjectNode)
		 * responseJsnNd.get("responses").get(0).get("hits"));
		 * 
		 * JsonNode jsonNode =
		 * responseObjNd.get("responses").get(0).get("hits"); JsonNode jsonNode2
		 * = responseObjNd.get("responses").get(0).get("hits");
		 * 
		 * responseObjNd.put("hits", jsonNode2);
		 */

		// JSONObject

		// responseJsnNd.get("response").get(0);
		// log.info(responseJsnNd.toString());
		// responseJsnNd.get(arg0)
		// create an array of highlight in normal and in lower case.

		// StringBuilder highlightedResponse =

		return mergedResponse;// put.toString();
	}

	private void fillHits(JsonNode responseJsnNd) {
		// TODO Auto-generated method stub

	}

}
