package com.cralwer;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cralwer.service.CrawlAndMonitor;
import com.cralwer.util.CralwerUtils;

@RestController
public class Controller {

	@Autowired
	CralwerUtils cralwerUtils;
	
	
	@Autowired
	CrawlAndMonitor crawlAndMonitor;
	
	
	Logger log = LoggerFactory.getLogger(this.getClass());

	@PostMapping(value = "/start/params")
	public String startCrawler(@RequestBody Map<String, String> params) throws IOException{
		
		// Can change map to object
		log.info("recieved request: "+ params);
		// validation
		if(cralwerUtils.validateRequest(params))
			return "could not start";
		
		Path dir = Paths.get(params.get("dirWithSubDir"));
		
		crawlAndMonitor.startCrawl(dir, true, Boolean.valueOf(params.get("indexDataOnStartUp")));
		log.info("crawler started");
		crawlAndMonitor.processEvents();
		
		
		return "Crawl and Monitor Stopped for" 
				+params.get("dirWithSubDir");
		
	}
}
