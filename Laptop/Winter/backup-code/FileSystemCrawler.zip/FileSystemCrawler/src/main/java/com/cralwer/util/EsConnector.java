/*package com.cralwer.util;

import javax.annotation.PreDestroy;

import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkProcessor;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder.HttpClientConfigCallback;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.client.RestHighLevelClient;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class EsConnector {

	@Autowired
	Environment environment;

	private final Logger log = LoggerFactory.getLogger(EsConnector.class);

	@Bean
	public RestHighLevelClient getEsClient() {
		final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
		credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(
				"elastic", "elastic123"));

		return new RestHighLevelClient(RestClient
				.builder(new HttpHost(environment.getProperty("es.hostname", "10.85.17.220"),
						Integer.parseInt(environment.getProperty("es.port", "9200")), "http"))
				.setHttpClientConfigCallback(new HttpClientConfigCallback() {
					@Override
					public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
						return httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
					}
				}));
	}

	@Bean
	public BulkProcessor bulkProcessor(){
	
	
		BulkProcessor.Listener listener = new BulkProcessor.Listener() {
			int count = 0;

			@Override
			public void beforeBulk(long l, BulkRequest bulkRequest) {
				count = count + bulkRequest.numberOfActions();
				log.info("Uploaded " + count + " so far");
			}

			@Override
			public void afterBulk(long l, BulkRequest bulkRequest, BulkResponse bulkResponse) {
				log.info("file size in bytes" + bulkRequest.estimatedSizeInBytes());
				if (bulkResponse.hasFailures()) {
					for (BulkItemResponse bulkItemResponse : bulkResponse) {
						if (bulkItemResponse.isFailed()) {
							log.error("bulk response: " + bulkItemResponse.getOpType());
							BulkItemResponse.Failure failure = bulkItemResponse.getFailure();
							log.error("Error " + failure.toString());
						}
					}
				}
			}

			@Override
			public void afterBulk(long l, BulkRequest bulkRequest, Throwable throwable) {
				log.error("BulkProcessor error ", throwable);
				log.error("indexed no of docs " + bulkRequest.numberOfActions());
			}
		};

		RestClient restClient = RestClient.builder(
			    new HttpHost("10.85.17.220", 9200, "http"),
			    new HttpHost("10.85.17.221", 9200, "http")).build();
		
//		return BulkProcessor.builder(restClient, listener);
		return BulkProcessor.builder(getEsClient().bulkAsync(bulkRequest, listener).setBulkActions(100)
					.setConcurrentRequests(8).setFlushInterval(TimeValue.timeValueSeconds(10)).build();
		
	}

	@PreDestroy
	public void destroyEsClient(){
//		bulkProcessor().close();
	log.debug("destroyed");
	}
}

package com.cralwer.util;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.action.bulk.BackoffPolicy;
import org.elasticsearch.action.bulk.BulkItemResponse;
import org.elasticsearch.action.bulk.BulkProcessor;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.bulk.BulkResponse;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestClientBuilder.HttpClientConfigCallback;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.unit.ByteSizeUnit;
import org.elasticsearch.common.unit.ByteSizeValue;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.threadpool.ThreadPool;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

@Configuration
public class EsConnector {
	@Autowired
	Environment environment;
	private final Logger log = LoggerFactory.getLogger(EsConnector.class);
	@Bean
	public RestHighLevelClient getEsClient() {
		final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
		credentialsProvider.setCredentials(AuthScope.ANY, new UsernamePasswordCredentials(
				environment.getProperty("elastic.user"), environment.getProperty("elastic.pwd")));
		return new RestHighLevelClient(RestClient
				.builder(new HttpHost(environment.getProperty("es.hostname", "localhost"),
						Integer.parseInt(environment.getProperty("es.port", "9200")), "http"))
				.setHttpClientConfigCallback(new HttpClientConfigCallback() {
					@Override
					public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
						return httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
					}
				}));
	}
	@Bean
	public BulkProcessor bulkProcessor(){
	
	
		BulkProcessor.Listener listener = new BulkProcessor.Listener() {
			int count = 0;
			@Override
			public void beforeBulk(long l, BulkRequest bulkRequest) {
				count = count + bulkRequest.numberOfActions();
				log.info("Uploaded " + count + " so far");
			}
			@Override
			public void afterBulk(long l, BulkRequest bulkRequest, BulkResponse bulkResponse) {
				log.info("file size in bytes" + bulkRequest.estimatedSizeInBytes());
				if (bulkResponse.hasFailures()) {
					for (BulkItemResponse bulkItemResponse : bulkResponse) {
						if (bulkItemResponse.isFailed()) {
							log.error("bulk response: " + bulkItemResponse.getOpType());
							BulkItemResponse.Failure failure = bulkItemResponse.getFailure();
							log.error("Error " + failure.toString());
						}
					}
				}
			}
			@Override
			public void afterBulk(long l, BulkRequest bulkRequest, Throwable throwable) {
				log.error("BulkProcessor error ", throwable);
				log.error("indexed no of docs " + bulkRequest.numberOfActions());
			}
		};
		
		BulkProcessor.Builder(getEsClient()::bulkAsync, listener, threadPool);
		builder.setBulkActions(500); 
		builder.setBulkSize(new ByteSizeValue(1L, ByteSizeUnit.MB)); 
		builder.setConcurrentRequests(0); 
		builder.setFlushInterval(TimeValue.timeValueSeconds(10L)); 
		builder.setBackoffPolicy(BackoffPolicy.constantBackoff(TimeValue.timeValueSeconds(1L), 3)); )
		return BulkProcessor.builder(getEsClient()::bulkAsync, listener).setBulkActions(1)
//				.setBulkSize(new ByteSizeValue(15, ByteSizeUnit.MB))
				.setConcurrentRequests(1).build();
		
	}
	
}*/