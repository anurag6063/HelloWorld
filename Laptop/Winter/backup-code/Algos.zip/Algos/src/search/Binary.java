package search;

public class Binary {

	public static void main(String ...strings ){
		
		System.out.println("started");
		Binary binary = new Binary();
		System.out.println(binary.rootOf(2));
		
	}

	private long rootOf(long x) {
	

	     System.out.println("x is: " + x);
		// Your code here
		if( x != 0 ){
		    
		    long l = 0;
		    long h = x; 
		    long m =0;
		    long ans = 0;
		    while(l <= h ){
		       m = l + (h - l)/2;
		       System.out.println("mid is: " + m);
		       if(m*m == x) 
		         return m;
		      else if (m*m > x)
		        {h = m -1 ;
		        
		        }
		      else if (m*m < x)
		        {l = m + 1;
		       ans = m;
		        }
		    }
		    System.out.println("ans wer is : "+ ans);
		    return ans;
		}
		return 0;
	 }
	}

