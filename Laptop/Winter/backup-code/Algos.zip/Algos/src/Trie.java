
//https://www.geeksforgeeks.org/trie-insert-and-search/

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;

public class Trie {

	static class Node {
		Node[] nodes = new Node[26];
		boolean isEnd;

		Node() {
			isEnd = false;
			for (int i = 0; i < 26; i++) {
				nodes[i] = null;
			}
		}
	}

	class FastScanner {
		StringTokenizer tok = new StringTokenizer("");
		BufferedReader in;

		FastScanner() {
			in = new BufferedReader(new InputStreamReader(System.in));
		}

		String next() throws IOException {
			while (!tok.hasMoreElements())
				tok = new StringTokenizer(in.readLine());
			return tok.nextToken();
		}

		int nextInt() throws IOException {
			return Integer.parseInt(next());
		}
	}

	List<Map<Character, Integer>> new_buildTrie(String[] patterns) {
		List<Map<Character, Integer>> trie = new ArrayList<Map<Character, Integer>>();

		Node root = new Node();
		int index;
		for (int i = 0; i < patterns.length; i++) {

			String pattern = patterns[i];
			Node currentNode = root;
			for (int j = 0; j < pattern.length(); j++) {

				index = pattern.charAt(j) - 'a';
				if (currentNode.nodes[j] == null) {
					currentNode.nodes[j] = new Node();
				} else {
					currentNode = currentNode.nodes[j];

				}

				currentNode.isEnd = true;
			}

		}

		return trie;
	}

	List<Map<Character, Integer>> buildTrie(String[] patterns) {
		
		List<Map<Character, Integer>> trie = new ArrayList<Map<Character, Integer>>();
// for each pattern
		for (int i = 0; i < patterns.length; i++) {

			Map<Character, Integer> currentNode = new HashMap();
			
			String pattern = patterns[i];
			
			for (int j = 0; j < pattern.length(); j++) {
				
				char currentChar = pattern.charAt(j);
				if(currentNode.containsKey(currentChar)){
//					currentNode = currentNode.get(currentChar);
				}else{
					
				}
				
			}
		}
		
		Map<Character, Integer> t = new HashMap<>();
		t.put('A', 0);
		trie.add(t);
	

	return trie;

	}

	static public void main(String[] args) throws IOException {
		new Trie().run();
	}

	public void print(List<Map<Character, Integer>> trie) {
		for (int i = 0; i < trie.size(); ++i) {
			Map<Character, Integer> node = trie.get(i);
			for (Map.Entry<Character, Integer> entry : node.entrySet()) {
				System.out.println(i + "->" + entry.getValue() + ":" + entry.getKey());
			}
		}
	}

	public void run() throws IOException {
		FastScanner scanner = new FastScanner();
		int patternsCount = scanner.nextInt();
		String[] patterns = new String[patternsCount];
		for (int i = 0; i < patternsCount; ++i) {
			patterns[i] = scanner.next();
		}
		List<Map<Character, Integer>> trie = buildTrie(patterns);
		print(trie);
	}
}
