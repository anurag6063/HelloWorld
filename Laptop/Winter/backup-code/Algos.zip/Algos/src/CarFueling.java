import java.util.*;
import java.io.*;

public class CarFueling {
    static int computeMinRefills(int dist, int tank, int[] stops) {
    	
    	/*int count =0;
    	int i=0;
    	int disCovered=0;
    	int N= dist;
    	int lastStop = 0;
    	int currentStop = 0;
    	int noOfStops = stops.length-1;
    	while(disCovered < N){
    		
    		if(i < noOfStops && stops[i]<= (disCovered + tank)){
    			disCovered = stops[i];
    			i++;
    		}
    		else{
    			disCovered = disCovered+ tank;
    		}
    		
    		
    		if(disCovered < N  ){
    			count++;
    		}
    		
    	}
    	return count;*/
    	int noOfRefills = 0;
    	int currentRefills = 0;
    	
    	int[] stopsNew = new int[stops.length +2];
    	stopsNew[0] = 0;
    	stopsNew[stopsNew.length - 1] = dist;
    	int n = stopsNew.length-2;
    	
    	
    	
    	for(int i = 0; i < stops.length; i++){
    		stopsNew[i+1]= stops[i];
    	}
    	
    	while(currentRefills <= n){
    		System.out.println("index is: "+ currentRefills);
    		int lastRefill = currentRefills;
    		while(currentRefills <= n &&
    				stopsNew[currentRefills+1]-stopsNew[lastRefill]<=tank){
    			currentRefills = currentRefills+1;
    			}
    		
    		
    		
    			if(currentRefills == lastRefill)
    				return -1;

    			if(currentRefills <= n)
    				noOfRefills++;
    	}
    	
    	 return noOfRefills;
    	 
    	 
    	/*int refills =0;
    	for(int i=0;i< stops.length-1; i++){
    		if(stops[i+1] - stops[i] > tank){
    			return -1;
    			
    		}else {
    			refills++;
    			dist = dist - stops[i];
    		}
    	}
    	*/
//       
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int dist = scanner.nextInt();
        int tank = scanner.nextInt();
        int n = scanner.nextInt();
        int stops[] = new int[n];
        for (int i = 0; i < n; i++) {
            stops[i] = scanner.nextInt();
        }

        System.out.println(computeMinRefills(dist, tank, stops));
    }
}
