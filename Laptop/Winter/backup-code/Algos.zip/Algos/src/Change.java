import java.util.Scanner;

public class Change {
    private static int getChange(int m) {
        //write your code here
    	int count =0;
    	
    	count = count + m/10;
    	m=m-m/10*10;
    	
    	count = count +  m/5;
    	m=m-m/5*5;
    	
    	count += m/1;
    	m=m-m/1*1;
    	
    	
        return count;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int m = scanner.nextInt();
        System.out.println(getChange(m));

    }
}

