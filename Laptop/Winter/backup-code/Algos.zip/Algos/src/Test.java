
public class Test {

	public static void main(String[] args) {
		
		
		System.out.println("test," +  " CA OPS MVS Event Management & Automation".substring("CA OPS MVS Event Management & Automation".indexOf("-")+1) + ","); 
	}
}
