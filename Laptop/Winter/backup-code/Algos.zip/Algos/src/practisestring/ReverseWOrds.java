/*package practisestring;

import java.util.Arrays;
import java.util.Collections;

public class ReverseWOrds {

	
	public static void main(String[] args) {

		//code
		
		String text = "i.like.this.program.very.much";
		
		String[] words = text.split("\\W");
//		Arrays.sort(words, Collections.reverseOrder());
		
		for(int i = words.length -1 ; i >= 0; i--){
			if(i != 0){
			System.out.print(words[i]+".");
			}else{
				System.out.print(words[i]);	
			}
		}
		
//		Arrays.stream(words).forEach(System.out::print);
		
		
	
	}
}


import java.lang.*;
import java.io.*;

class GFG {
	public static void main (String[] args) {
		//code
		Scanner sc=new Scanner(System.in);
		int t=sc.nextInt();
		while(t-->0)
		{
		 String s=sc.next();
		 String str[]=s.split("\\.");
		 for(int i=str.length-1;i>=0;i--)
       {
    System.out.print(str[i]);
    if(i>0)
    System.out.print(".");
     }
     System.out.println();
	}
}
}*/