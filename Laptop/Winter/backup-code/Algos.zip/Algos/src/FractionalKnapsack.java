import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class FractionalKnapsack {
    private static double getOptimalValue(int capacity, int[] values, int[] weights) {
        double value = 0;
        //write your code here
        Item[] items= new Item[values.length];
        
        for(int i=0;i<values.length;i++){
        	items[i] = new Item(weights[i], values[i], i);
        }
        
        Arrays.sort(items, new Comparator<Item>() {

			@Override
			public int compare(Item o1, Item o2) {
				// TODO Auto-generated method stub
				return o2.cost.compareTo(o1.cost);
			}
		
        
        });
        
        double totalValue=0d;
        for(Item i : items){
        	
        	// pick whole
        	if(capacity - (int) i.wgt >= 0){
        		
        		capacity= capacity-(int) i.wgt;
        		totalValue += (int) i.val;
        	}else {
        		
        		double fraction = (double) capacity / (double) i.wgt;
        		
        		capacity =capacity - ((int) fraction * (int) i.wgt);
        		totalValue = totalValue + fraction*i.val;
        		break;
        		
        	}
        	
        }
       

        return totalValue;
    }

    public static void main(String args[]) {
        Scanner scanner = new Scanner(System.in);
        int n = scanner.nextInt();
        int capacity = scanner.nextInt();
        int[] values = new int[n];
        int[] weights = new int[n];
        for (int i = 0; i < n; i++) {
            values[i] = scanner.nextInt();
            weights[i] = scanner.nextInt();
        }
        System.out.println(getOptimalValue(capacity, values, weights));
    }
    
    static class Item{
    	
    	double val, wgt, ind;
    	
    	Double cost;
    	
    	public Item(double wgt, double val, double ind){
    		
    		this.wgt=wgt;
    		this.val=val;
    		this.ind=ind;
    		
    		cost= new Double(val/wgt);
    	}
    
    }
} 
