package com.search.es.config;

import java.io.IOException;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HighRestClient {
	

	@Bean
	public RestHighLevelClient getEsClient() throws IOException {		
		
		RestHighLevelClient client = new RestHighLevelClient(
		        RestClient.builder(
//		                new HttpHost("135.36.0.89", 9201, "http")));
        new HttpHost("localhost", 9200, "http")));


		System.out.println(client.ping());
		
		return client;

	}
	

}
