package com.search.es;

import java.io.IOException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.search.es.service.SearchService;
import com.search.es.vo.IncomingSearchRequest;
import com.search.es.vo.SearchResponseCommon;
import com.search.es.vo.SearchResponseCompanySuggestion;

@RestController
public class WebControllerSearch {

	@Autowired SearchService searchService;
	
	@PostMapping(value="/search")
	public @ResponseBody SearchResponseCommon searching(@RequestBody IncomingSearchRequest searchRequest){
		
		
		System.out.println(searchRequest.getInquiry());
		
		
		
		SearchResponseCommon searchResponse= new SearchResponseCommon();
		searchResponse.setDescription("First");
		searchResponse.setHighlight("highlight");
		searchResponse.setTitle("my title");
		searchResponse.setLink("url");
		
		return searchResponse;
	}
	
	@PostMapping(value="/suggest/company")
	public @ResponseBody ArrayList<SearchResponseCompanySuggestion> companySuggestion(@RequestBody IncomingSearchRequest searchRequest) throws IOException{
		
		
		System.out.println(searchRequest.getInquiry());
		ArrayList<SearchResponseCompanySuggestion> suggestedCompanies = searchService.suggestCompany(searchRequest);

		return suggestedCompanies;
	}
	
	@PostMapping(value="/search/basic")
	public @ResponseBody ArrayList<SearchResponseCommon> searchSQR(@RequestBody IncomingSearchRequest searchRequest) throws IOException{
		
		
		System.out.println(searchRequest.getInquiry());
		ArrayList<SearchResponseCommon> suggestedCompanies = searchService.searchBasic(searchRequest);

		return suggestedCompanies;
	}
}
