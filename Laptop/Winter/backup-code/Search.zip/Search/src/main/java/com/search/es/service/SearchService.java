package com.search.es.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.common.unit.TimeValue;
import org.elasticsearch.index.query.MatchQueryBuilder;
import org.elasticsearch.index.query.Operator;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.SimpleQueryStringBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.elasticsearch.search.fetch.subphase.highlight.HighlightBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.search.es.config.HighRestClient;
import com.search.es.vo.IncomingSearchRequest;
import com.search.es.vo.SearchResponseCommon;
import com.search.es.vo.SearchResponseCompanySuggestion;

@Component
public class SearchService {

//	public searchWithWildcard(Search)
	
	@Autowired HighRestClient hrc;
	
	public ArrayList<SearchResponseCompanySuggestion> suggestCompany(IncomingSearchRequest incomingSearchRequest) throws IOException
	{

		
		SearchSourceBuilder searchSourceBuilder= new SearchSourceBuilder();
		MatchQueryBuilder matchQueryBuilder =QueryBuilders.matchQuery("company_name", incomingSearchRequest.getInquiry()).operator(Operator.AND);
		searchSourceBuilder.query(matchQueryBuilder);
		searchSourceBuilder.size(10);
		searchSourceBuilder.timeout(new TimeValue(2, TimeUnit.SECONDS));
		
		
		
		SearchRequest searchRequest = new SearchRequest("csp_t_tmp_nda");
		searchRequest.types("_doc");
		searchRequest.source(searchSourceBuilder);
		SearchResponse searchResponse = hrc.getEsClient().search(searchRequest);
		
		
		ArrayList<SearchResponseCompanySuggestion> listCompany = new ArrayList<>();
		
		for(SearchHit searchHit : searchResponse.getHits().getHits()){

			SearchResponseCompanySuggestion searchResponseCs = new SearchResponseCompanySuggestion();
			
			Map<String, Object> result = searchHit.getSourceAsMap();
		
			
			searchResponseCs.setCompanyId((Integer) result.get("company_id"));
			searchResponseCs.setComanyName(result.get("company_name").toString());
			listCompany.add(searchResponseCs);
		
		}
		
		return listCompany;
	}
	

	public ArrayList<SearchResponseCommon> searchBasic(IncomingSearchRequest incomingSearchRequest) throws IOException
	{

		
		SearchSourceBuilder searchSourceBuilder= new SearchSourceBuilder();
	/*	MatchQueryBuilder matchQueryBuilder =QueryBuilders.matchQuery("company_name", incomingSearchRequest.getInquiry()).operator(Operator.AND);
		searchSourceBuilder.query(matchQueryBuilder);
		searchSourceBuilder.size(10);
		searchSourceBuilder.timeout(new TimeValue(2, TimeUnit.SECONDS));
		*/
		
		SimpleQueryStringBuilder simpleQuery = QueryBuilders.simpleQueryStringQuery(incomingSearchRequest.getInquiry());
	//	simpleQuery.field("product", 2);
		HighlightBuilder highlightBuilder = new HighlightBuilder()
		        .postTags("<highlight>")
		        .preTags("</highlight>")
		        .field("title");
		
		SearchRequest searchRequest = new SearchRequest("es_poc");
		searchRequest.source(searchSourceBuilder);
		SearchResponse searchResponse = hrc.getEsClient().search(searchRequest);
		
		
		ArrayList<SearchResponseCommon> listResponse = new ArrayList<>();
		
		for(SearchHit searchHit : searchResponse.getHits().getHits()){

		SearchResponseCommon searchResponseCommon = new SearchResponseCommon();
			
			Map<String, Object> result = searchHit.getSourceAsMap();
		
			
			searchResponseCommon.setTitle(result.get("product").toString());
			
			listResponse.add(searchResponseCommon);
		
		}
		
		return listResponse;
	}
}
