package com.search.config;

import org.deeplearning4j.models.embeddings.loader.WordVectorSerializer;
import org.deeplearning4j.models.word2vec.Word2Vec;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LoadModel {
	
	@Bean
	public Word2Vec loadTrainedModel(){
		
		Word2Vec readWord2VecModel = WordVectorSerializer.readWord2VecModel("C:/Users/anuryadav/Desktop/Python/practise/session4/groupLab/Grouplab2/Word2vec_MB/Word2vec_MB/model.txt");

		return readWord2VecModel;
	}

	
}
