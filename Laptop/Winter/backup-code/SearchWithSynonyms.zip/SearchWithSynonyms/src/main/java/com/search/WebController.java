package com.search;

import java.util.Collection;

import org.deeplearning4j.models.word2vec.Word2Vec;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WebController {

	@Autowired
	Word2Vec word2Vec;
	
	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@GetMapping("/")
	public String searchSynonyms(String term, String text){
		
		log.info("Terms recieved "+ term);
		
		// use
		Collection<String> wordsNearest = word2Vec.wordsNearest(term, 5);
		
		return "Terms recieved "+ term + "Nearest word  to term "+ wordsNearest.toArray();
	}
}
