
package com.example;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "Product",
    "Document Type"
})
public class Filters {

    @JsonProperty("Product")
    private List<Product> product = null;
    @JsonProperty("Document Type")
    private List<DocumentType> documentType = null;

    @JsonProperty("Product")
    public List<Product> getProduct() {
        return product;
    }

    @JsonProperty("Product")
    public void setProduct(List<Product> product) {
        this.product = product;
    }

    @JsonProperty("Document Type")
    public List<DocumentType> getDocumentType() {
        return documentType;
    }

    @JsonProperty("Document Type")
    public void setDocumentType(List<DocumentType> documentType) {
        this.documentType = documentType;
    }

}
