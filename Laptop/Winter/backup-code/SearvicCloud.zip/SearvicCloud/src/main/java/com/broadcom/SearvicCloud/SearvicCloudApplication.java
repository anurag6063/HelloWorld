package com.broadcom.SearvicCloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SearvicCloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SearvicCloudApplication.class, args);
	}

}
