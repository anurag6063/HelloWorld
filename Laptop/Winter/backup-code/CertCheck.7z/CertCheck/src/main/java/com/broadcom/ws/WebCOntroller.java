package com.broadcom.ws;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class WebCOntroller {
	
	@Autowired
	ObjectMapper mapper;
	
	@Autowired
	RestTemplate restTemplate;

	Logger log = LoggerFactory.getLogger(this.getClass());

	
	@GetMapping(value = "/search")
	public String searching() throws JsonProcessingException
	{
		
		QUery quUery = new QUery();
		quUery.setEmail("WSD_ADMIN@wolkensoftware.com");
		quUery.setQuery("test");
		
		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/json");

		log.info("es query to be fired {} ", mapper.writeValueAsString(quUery.toString()));

		HttpEntity<String> httpEntity = new HttpEntity<>(mapper.writeValueAsString(quUery), httpHeaders);

		
		log.info("searchRequest recieved {}", mapper.writeValueAsString(quUery));
		String response =  restTemplate.postForObject("https://stg-enterprise.broadcom.com/broadcom/v1/elasticsearchws/search", httpEntity, String.class);
		log.info(response);
		return response;
		
	}

}
