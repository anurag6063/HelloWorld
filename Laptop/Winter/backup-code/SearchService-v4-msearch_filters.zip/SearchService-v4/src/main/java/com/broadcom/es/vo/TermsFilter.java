package com.broadcom.es.vo;

public class TermsFilter {

	Terms terms;

	public Terms getTerms() {
		return terms;
	}

	public void setTerms(Terms terms) {
		this.terms = terms;
	}
	
	
	
	
}
