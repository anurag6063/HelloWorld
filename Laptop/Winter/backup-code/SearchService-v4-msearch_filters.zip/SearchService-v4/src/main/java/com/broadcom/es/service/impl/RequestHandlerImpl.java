package com.broadcom.es.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.MultiValuedMap;
import org.apache.commons.collections4.multimap.ArrayListValuedHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.broadcom.es.vo.Template;
import com.broadcom.es.vo.Terms;
import com.broadcom.es.vo.TermsFilter;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class RequestHandlerImpl {

	
	@Autowired
	RestTemplate restTemplate;
	
	Logger log = LoggerFactory.getLogger(this.getClass());
	ObjectMapper mapper = new ObjectMapper();

	public Map<String, Object> modifyFilters(String string, Map<String, Object> searchRequest)
			throws JsonProcessingException {

		MultiValuedMap<String, String> mvmFilters = new ArrayListValuedHashMap<>();

		// create a multi-map of filters
		ArrayList<LinkedHashMap<String, String>> filters = (ArrayList<LinkedHashMap<String, String>>) searchRequest
				.get("filters");

		for (int i = 0; i < filters.size(); i++) {
			LinkedHashMap<String, String> linkedHashMap = filters.get(i);
			mvmFilters.putAll(linkedHashMap);
		}

		// modify the keys if multi-map to name according to ES name.

		// create the mappping as needed in term filters:
		// ArrayList<Terms> termsList = new ArrayList<>();

		TermsFilter termsFilter = new TermsFilter();

		Set<String> keySet = mvmFilters.keySet();
		StringBuilder termsStringES = new StringBuilder();
		for (String key : keySet) {
			Terms terms = new Terms();
			terms.setKey(key);
			terms.setValue(mvmFilters.get(key));
			log.debug("");
			ObjectMapper mapper = new ObjectMapper();
			String termsString = mapper.writeValueAsString(terms);
			termsStringES.append(",{ \"terms\" : {\"").append(key).append(".keyword\" : ")
					.append(mapper.writeValueAsString(mvmFilters.get(key))).append(" } }");

		}
		String termsStringES2 = termsStringES.toString()// .replace("\"",
														// "\\\"")
				.replace("Product", "product").replace("Document Types", "doctype_name");
		log.info(termsStringES2);
		// searchRequest.remove("filters");
		searchRequest.put("termsFilter", termsStringES2);

		/*
		 * ObjectMapper mapper = new ObjectMapper(); String termsString =
		 * mapper.writeValueAsString(searchRequest); log.debug("");
		 */

		return searchRequest;
	}

	/*
	 * uses the original request. modified only filters.
	 * 
	 * 
	 */
	public StringBuilder buildEsRequest(Map<String, Object> searchRequest) throws JsonProcessingException {

		StringBuilder esQuery = new StringBuilder();

		if ((boolean) searchRequest.get("csp") == true) {
			makeIndexQuery("csp", searchRequest, esQuery);
			makeTemplate("csp", searchRequest, esQuery);
		}

		if ((boolean) searchRequest.get("cases") == true) {
			makeIndexQuery("cases", searchRequest, esQuery);
			makeTemplate("cases", searchRequest, esQuery);
		}

		return esQuery;
	}

	private StringBuilder makeTemplate(String app, Map<String, Object> searchRequest, StringBuilder esQuery)
			throws JsonProcessingException {

		if (app.equalsIgnoreCase("csp")) {

			Template templateCsp = new Template();
			templateCsp.setId("csp_v8");

			Map<String, Object> searchRequestCsp = new HashMap<>();
			searchRequestCsp.putAll(searchRequest);
			searchRequestCsp = modifyFilters("csp", searchRequestCsp);

			searchRequestCsp.remove("filters");
			searchRequestCsp.remove("csp");
			searchRequestCsp.remove("cases");
			templateCsp.setParams(searchRequestCsp);

			esQuery.append(mapper.writeValueAsString(templateCsp)).append("\n");
		}
		if (app.equalsIgnoreCase("cases")) {

			Template templateCases = new Template();
			templateCases.setId("cases_v1");
			Map<String, Object> searchRequestCases = new HashMap<>();
			searchRequestCases.putAll(searchRequest);
			searchRequestCases = modifyFilters("cases", searchRequestCases);
			templateCases.setParams(searchRequestCases);

			esQuery.append(mapper.writeValueAsString(templateCases)).append("\n");
		}

		return esQuery;
	}

	private StringBuilder makeIndexQuery(String app, Map<String, Object> searchRequest, StringBuilder esQuery)
			throws JsonProcessingException {

		Map<String, String> index = new HashMap<>();
		if (app.equalsIgnoreCase("csp")) {
			index.put("index", "doc_safe_dev_local_v1");
			esQuery.append(mapper.writeValueAsString(index)).append("\n");
		} else if (app.equalsIgnoreCase("cases")) {
			index.put("index", "cases");
			esQuery.append(mapper.writeValueAsString(index)).append("\n");
		}

		return esQuery;

	}

	public String doSearch(StringBuilder esQuery) {

		HttpHeaders httpHeaders = new HttpHeaders();
		httpHeaders.set("Content-Type", "application/x-ndjson");

//		esQuery.toString().replace("\n", "\\\\n")
		log.debug("es query to be fired", esQuery);
		
		HttpEntity<String> httpEntity = new HttpEntity<String>(esQuery.toString(), httpHeaders);

		String response = restTemplate.postForObject("http://135.36.0.89:9201/_msearch/template", httpEntity,
				String.class);
		
		return response;
	}

}
