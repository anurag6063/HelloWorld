package com.broadcom.es;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.broadcom.es.service.impl.RequestHandlerImpl;
import com.fasterxml.jackson.core.JsonProcessingException;

@RestController
public class WebController {
	
	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	RequestHandlerImpl requestHandlerImpl;
	
	@PostMapping(value="/search")
	public String searching(@RequestBody Map<String,Object> searchRequest) throws JsonProcessingException{
		
		log.info("searchRequest recieved" + searchRequest.toString());
		
		// validate request force all the params to be present. and specific values too.
		
		
		// build ES request
		StringBuilder esQuery = requestHandlerImpl.buildEsRequest(searchRequest);
		
		
		// do rest call to get back list of responses
		String response  = requestHandlerImpl.doSearch(esQuery);
		
		return response;
	}
	
	

}
