package com.broadcom.es.vo;

import java.util.Collection;
import java.util.List;

public class Terms {

	String key;
	Collection<String> value;
	
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public Collection<String> getValue() {
		return value;
	}
	public void setValue(Collection<String> value) {
		this.value = value;
	}
	
	
	
}
