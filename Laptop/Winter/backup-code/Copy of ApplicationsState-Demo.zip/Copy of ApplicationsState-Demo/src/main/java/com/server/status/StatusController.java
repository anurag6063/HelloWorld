package com.server.status;

import java.io.IOException;
import java.text.ParseException;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StatusController {

	
	@RequestMapping("/status")
	public ModelAndView showStatusJava(Model model,
			@RequestParam(value = "date", required = false, defaultValue = "0") String date,
			@RequestParam(value = "tz", required = false, defaultValue = "America/Los_Angeles") String tz,
			HttpServletRequest request
			)
			throws ParseException, IOException {

		System.out.println("date passed: " + date);
		System.out.println("tz passed: " + tz);

		ModelAndView mav = new ModelAndView("statusJava");

		mav.addObject("headers", "header");

		mav.addObject("response", "response");
//		mav.addObject("response", data);


		return mav;

	}

	
}
