
package com.example;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "key_as_string",
    "key",
    "doc_count",
    "nested_server_agg"
})
public class Bucket {

    @JsonProperty("key_as_string")
    private String keyAsString;
    @JsonProperty("key")
    private Integer key;
    @JsonProperty("doc_count")
    private Integer docCount;
    @JsonProperty("nested_server_agg")
    private NestedServerAgg nestedServerAgg;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("key_as_string")
    public String getKeyAsString() {
        return keyAsString;
    }

    @JsonProperty("key_as_string")
    public void setKeyAsString(String keyAsString) {
        this.keyAsString = keyAsString;
    }

    @JsonProperty("key")
    public Integer getKey() {
        return key;
    }

    @JsonProperty("key")
    public void setKey(Integer key) {
        this.key = key;
    }

    @JsonProperty("doc_count")
    public Integer getDocCount() {
        return docCount;
    }

    @JsonProperty("doc_count")
    public void setDocCount(Integer docCount) {
        this.docCount = docCount;
    }

    @JsonProperty("nested_server_agg")
    public NestedServerAgg getNestedServerAgg() {
        return nestedServerAgg;
    }

    @JsonProperty("nested_server_agg")
    public void setNestedServerAgg(NestedServerAgg nestedServerAgg) {
        this.nestedServerAgg = nestedServerAgg;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("keyAsString", keyAsString).append("key", key).append("docCount", docCount).append("nestedServerAgg", nestedServerAgg).append("additionalProperties", additionalProperties).toString();
    }

}
