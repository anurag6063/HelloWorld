DROP TABLE IF EXISTS products;
 
CREATE TABLE products (
  sku INT AUTO_INCREMENT  PRIMARY KEY,
  size VARCHAR(250) NOT NULL,
  seller VARCHAR(250) NOT NULL,
  brand VARCHAR(250) DEFAULT NULL,
  color VARCHAR(250) NOT NULL,
  tags VARCHAR(250) DEFAULT NULL,
  price INT NOT NULL
);
 
INSERT INTO products (size, seller, brand, color, tags, price) VALUES
  ('M', 'amazon', 'pepe jeans', 'red', 'pepe, jeans', 1000),
  ('M', 'ab', 'pepe jeans', 'red', 'pepe, jeans', 2000),
  ('M', 'an', 'pepe jeans', 'red', 'pepe, jeans', 3000),
  ('M', 'tesla', 'pepe jeans', 'red', 'pepe, jeans', 4000);