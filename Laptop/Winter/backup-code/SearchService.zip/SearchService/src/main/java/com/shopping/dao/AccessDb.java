package com.shopping.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.shopping.vo.Product;
//import org.springframework.jdbc.core.JdbcTemplate;

@Component
public class AccessDb {
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public List<Product> getDetails(Map<String, String> request){
		String sql = "select * from products where seller like '%"+ request.get("query") + "%'";
//		jdbcTemplate.execute("select * from ai_data_feed");
		List<Product>  result= jdbcTemplate.query(sql , new BeanPropertyRowMapper(Product.class));
		return result;
		
	}

	public List<Product> getGroupOf(Map<String, String> request) {
		// TODO Auto-generated method stub
		
		String sql = "select "+ request.get("group")+" from products where seller like '%"+ request.get("query") + "%' group by " + request.get("group") ;
//		jdbcTemplate.execute("select * from ai_data_feed");
		List<Product>  result= jdbcTemplate.query(sql , new BeanPropertyRowMapper(Product.class));
		return result;
		
//		return null;
	}

	public List<Product> getBySku(Map<String, String> request) {
		// TODO Auto-generated method stub
		

		String sql = "select * from products where sku= '"+ request.get("sku") + "'";
//		jdbcTemplate.execute("select * from ai_data_feed");
		List<Product>  result= jdbcTemplate.query(sql , new BeanPropertyRowMapper(Product.class));
		return result;
		
//		return null;
	}

	public ArrayList<Map<String, String>> getproductBySeller(Map<String, String> request) {
		// TODO Auto-generated method stub
		
		String sql = "select seller, count(*) from products group by seller" ; //" + request.get("group") ;

		ArrayList<Map<String,String>>  result= (ArrayList<Map<String, String>>) jdbcTemplate.query(sql , new BeanPropertyRowMapper(HashMap.class));
		return result;
//		return null;
	}

}
