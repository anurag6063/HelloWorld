package com.shopping;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.shopping.dao.AccessDb;
import com.shopping.utils.CommonUtils;
import com.shopping.vo.Product;

@RestController
public class Controller {
	
	
	@Autowired
	CommonUtils commonUtils;
	
	@Autowired 
	AccessDb accessDb;
	
	Logger log = LoggerFactory.getLogger(this.getClass());
	
	@PostMapping(value = "/search")
	public List<Product> getProduct(@RequestBody Map<String,String> request){
		
		log.info("Inside search request!");
		commonUtils.validateRequest(request);
		
		
		log.info("searching db for product");
		List<Product> products = accessDb.getDetails(request);
		
		return products;
	} 
	@PostMapping(value = "/group")
	public List<Product> getProductByGroup(@RequestBody Map<String,String> request){
		
		log.info("Inside search request!");
		commonUtils.validateRequest(request);
		
		
		log.info("searching db for product");
		List<Product> products = accessDb.getGroupOf(request);
		
		return products;
	} 

	@PostMapping(value = "/getBySku")
	public List<Product> getProductBySku(@RequestBody Map<String,String> request){
		
		log.info("Inside search request!");
		commonUtils.validateRequest(request);
		
		
		log.info("searching db for product");
		List<Product> products = accessDb.getBySku(request);
		
		return products;
	} 
	@PostMapping(value = "/productBySeller")
	public ArrayList<Map<String, String>> getproductBySeller(@RequestBody Map<String,String> request){
		
		log.info("Inside search request!");
		commonUtils.validateRequest(request);
		
		
		log.info("searching db for product");
		return accessDb.getproductBySeller(request);
		
//		return products;
	} 

}
