package com.shopping.vo;

public class Product {

    private long sku;
    private String seller, brand, color, tags;
    private char size;
    private int price;
    
    
    
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public long getSku() {
		return sku;
	}
	public void setSku(long sku) {
		this.sku = sku;
	}
	public String getSeller() {
		return seller;
	}
	public void setSeller(String seller) {
		this.seller = seller;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public String getTags() {
		return tags;
	}
	public void setTags(String tags) {
		this.tags = tags;
	}
	public char getSize() {
		return size;
	}
	public void setSize(char size) {
		this.size = size;
	}
	@Override
	public String toString() {
		return "Product [sku=" + sku + ", seller=" + seller + ", brand=" + brand + ", color=" + color + ", tags=" + tags
				+ ", size=" + size + ", price=" + price + "]";
	}

	
	

    
    
    
   /* public Product(long id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    @Override
    public String toString() {
        return String.format(
                "Customer[id=%d, firstName='%s', lastName='%s']",
                id, firstName, lastName);
    }*/

    // getters & setters omitted for brevity
}