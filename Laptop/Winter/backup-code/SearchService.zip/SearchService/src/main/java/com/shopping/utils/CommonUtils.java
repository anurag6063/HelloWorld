package com.shopping.utils;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Component;

@Component
public class CommonUtils {
	
	public Map<String,String> validateRequest(Map<String, String> request){
		
		if(null == request){
			return (Map) new HashMap<String, String>() {{put("error", "Please pass request param");}};
		}
		else return request;
	}

}
