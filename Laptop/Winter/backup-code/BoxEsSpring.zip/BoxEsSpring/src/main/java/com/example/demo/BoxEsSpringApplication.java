package com.example.demo;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.box.sdk.BoxAPIConnection;
import com.box.sdk.BoxAPIException;
import com.box.sdk.BoxDeveloperEditionAPIConnection;
import com.box.sdk.BoxFile;
import com.box.sdk.BoxFolder;
import com.box.sdk.BoxItem;
import com.box.sdk.BoxUser;
import com.box.sdk.EncryptionAlgorithm;
import com.box.sdk.IAccessTokenCache;
import com.box.sdk.InMemoryLRUAccessTokenCache;
import com.box.sdk.JWTEncryptionPreferences;
import com.eclipsesource.json.JsonObject;

@SpringBootApplication
public class BoxEsSpringApplication {

	public static void main(String[] args) throws IOException {
		SpringApplication.run(BoxEsSpringApplication.class, args);
		
		BoxDeveloperEditionAPIConnection api = BoxEsSpringApplication.getServiceAccountConnection();
		//System.out.println("api called");
		BoxEsSpringApplication boxUtility= new BoxEsSpringApplication();
		BoxFolder rootFolder = new BoxFolder(api, boxUtility.SRC_FOLDER_ID);
		//BoxFolder rootFolder = BoxFolder.getRootFolder(api);
		BoxEsSpringApplication schdlUtility = new BoxEsSpringApplication();
		List<String> fileList = listFiles(api);
		System.out.println("no of files returned"+fileList.size());
		//schdlUtility.collaborateUserToFolder("");
		//BoxFile file = schdlUtility.searchFile(api,"US_export_policy.jar");
		//System.out.println(file.getInfo().getName());
		
	}
	
	
	private static final int MAX_CACHE_ENTRIES = 100;
	private Properties boxDetailProps;
	public static BoxDeveloperEditionAPIConnection boxEnterpriseDeveloperEditionAPIConnection;
	private final String DEST_FOLDER_ID;
	private final String SRC_FOLDER_ID;
	private BoxFile file = null;
	final static Logger logger = Logger.getLogger(BoxEsSpringApplication.class);
	
	public BoxEsSpringApplication() throws IOException{
		InputStream is = getClass().getClassLoader().getResourceAsStream("utility.properties");
		boxDetailProps = new Properties();
		boxDetailProps.load(is);
		SRC_FOLDER_ID = boxDetailProps.getProperty("src.folder.id");
		DEST_FOLDER_ID = boxDetailProps.getProperty("dest.folder.id");
	}
	
	/*
	 * Using the enterprise app details obtain a 
	 * connection to be used for connecting to Box
	 * 
	 * @return BoxDeveloperEditionAPIConnection
	 */
	public static BoxDeveloperEditionAPIConnection getServiceAccountConnection(){
		
		JsonObject authDetails = getAuthenticationDetails();
		JsonObject boxAppSetting = authDetails.get("boxAppSettings").asObject();
		JsonObject appAuth = boxAppSetting.get("appAuth").asObject();
		JWTEncryptionPreferences encryptionPref = new JWTEncryptionPreferences();
		encryptionPref.setPublicKeyID(appAuth.get("publicKeyID").asString());
		System.out.println("public key "+appAuth.get("publicKeyID").asString());
		encryptionPref.setPrivateKey(appAuth.get("privateKey").asString());
		System.out.println("public key "+appAuth.get("privateKey").asString());
		encryptionPref.setPrivateKeyPassword(appAuth.get("passphrase").asString());
		encryptionPref.setEncryptionAlgorithm(EncryptionAlgorithm.RSA_SHA_256);
		IAccessTokenCache accessTokenCache = new InMemoryLRUAccessTokenCache(MAX_CACHE_ENTRIES);	
		System.out.println("Getting BOX API connection");
        try{
	boxEnterpriseDeveloperEditionAPIConnection = BoxDeveloperEditionAPIConnection.getAppEnterpriseConnection
				(authDetails.get("enterpriseID").asString(),
						boxAppSetting.get("clientID").asString(), 
						boxAppSetting.get("clientSecret").asString(),
						encryptionPref,
						accessTokenCache);
        }catch(Exception e)
        {
        	System.out.println("EXCEPTION IN CONNECTION ");
        	e.printStackTrace();
        }
		System.out.println("BoxEsSpringApplication.getServiceAccountConnection() "+boxEnterpriseDeveloperEditionAPIConnection);
		//boxEnterpriseDeveloperEditionAPIConnection = BoxDeveloperEditionAPIConnection.getAppUserConnection("royz1box@gmail.com",boxAppSetting.get("clientID").asString(), boxAppSetting.get("clientSecret").asString(), encryptionPref,accessTokenCache);
		return boxEnterpriseDeveloperEditionAPIConnection;
	}
	
	public BoxFile searchFile(BoxAPIConnection api, String fileName) throws Exception{
		try{
			//this.searchFile(api, fileName,BoxFolder.getRootFolder(api));
			this.searchFile(api, fileName,new BoxFolder(api, SRC_FOLDER_ID));
		}catch(Exception e){
//			logger.error("Exception in searchFile - API, FileName"+e.toString());
			throw e;
		}
		return file;
	}
	
	private void searchFile(BoxAPIConnection api, String fileName, BoxFolder folder) throws InterruptedException{
		
			for(BoxItem.Info item : folder){
				try{
					if(item instanceof BoxFile.Info){
						//System.out.println("Name of file "+item.getName());
						logger.info("Name of file "+item.getName());
						if(fileName.equals(item.getName())){
							this.file = (BoxFile)item.getResource();
						}
					}else if(item instanceof BoxFolder.Info){
						searchFile(api, fileName, (BoxFolder)item.getResource());
					}
			}catch (BoxAPIException e){
				logger.error("Exception in searchFile"+e.toString());
				if (e.getResponseCode() == 429 || e.getResponseCode() == 500 || e.getResponseCode() == 503) {
						logger.debug("searchFile - Response Code:" + e.getResponseCode());
						logger.debug("searchFile - Sleeping for 1 mins due to Box API request Limit exceed!!!");
						TimeUnit.MINUTES.sleep(1);
				}
			}
		}
	}
	
	public BoxFile moveFile(BoxFile file, BoxAPIConnection api) throws Exception{
		BoxFile.Info fileInfo= null;
		BoxFile copiedFile= null;
		try{		
			String destFolderId = createFolder(DEST_FOLDER_ID,file.getInfo().getName(),api);
			BoxFolder destFolder = new BoxFolder(api, destFolderId);
			fileInfo = file.copy(destFolder);
			copiedFile = new BoxFile(api, fileInfo.getID());
		}
		catch(BoxAPIException e){
			logger.error("Exception in moveFile"+e.toString());
			
			if (e.getResponseCode() == 429 || e.getResponseCode() == 500 || e.getResponseCode() == 503) {
					logger.debug("moveFile - Response Code:" + e.getResponseCode());
					logger.debug("moveFile - Sleeping for 1 mins due to Box API request Limit exceed!!!");
					TimeUnit.MINUTES.sleep(1);
					this.moveFile(file, api);
			}
		
		} 
		
		return copiedFile;
	}
	
	public String createFolder(String destFolderId, String fileName, BoxAPIConnection api) throws Exception{
           
	       String childFolderID = null;
	        	try {
	        		BoxFolder parentFolder = new BoxFolder(api, destFolderId);
	        		String chldFolderName = fileName+System.nanoTime();
	        		BoxFolder.Info childFolderInfo = parentFolder.createFolder(chldFolderName); 
	        		childFolderID = childFolderInfo.getID();
	        	}
 	   	  	catch(Exception e){
 	   	  	logger.error("Exception in createFolder"+e.toString());
 	   	   		//e.printStackTrace();
 	   	   	}
	        return childFolderID;
	}
	
	public void collaborateUserToFolder(String SrcFolderId){
		
		BoxDeveloperEditionAPIConnection api = BoxEsSpringApplication.getServiceAccountConnection();
		BoxUser user = new BoxUser(api, "1879960532");
		//System.out.println(user.getInfo().getName());
		logger.info("User Name "+user.getInfo().getName());
		BoxFolder folder = new BoxFolder(api,"35880636252");
		folder.collaborate(user, com.box.sdk.BoxCollaboration.Role.EDITOR);
	}
	
	private static JsonObject getAuthenticationDetails(){
		JsonObject authDetailsJson = null;
		try{
			ClassLoader classLoader = BoxEsSpringApplication.class.getClassLoader();
			InputStream is = classLoader.getResourceAsStream("box_config.json");
			//IOUtils.toString(is,"UTF8");
			authDetailsJson = JsonObject.readFrom(IOUtils.toString(is,"UTF8"));
			System.out.println("json object stringify "+IOUtils.toString(is,"UTF8"));
		}catch(IOException io){
			//io.printStackTrace();
			logger.error("Exception in getAuthenticationDetails"+io.toString());
		}
		return authDetailsJson;
	}
	
	public static List<String> listFiles(BoxDeveloperEditionAPIConnection api) throws IOException{
		System.out.println("INSIDE LISTFILES");
		BoxEsSpringApplication boxUtility= new BoxEsSpringApplication();
  		BoxFolder rootFolder = new BoxFolder(api, boxUtility.SRC_FOLDER_ID);
  		System.out.println("SRC_FOLDER_ID "+boxUtility.SRC_FOLDER_ID);
  		//BoxFolder rootFolder = BoxFolder.getRootFolder(api);
  		List<String> fileNameLst = new ArrayList<String>();
		for (BoxItem.Info itemInfo : rootFolder) {                    
  
			if ( itemInfo instanceof  BoxFile.Info) {
				BoxFile boxfile = new BoxFile(api, itemInfo.getID());    	  						
				fileNameLst.add(boxfile.getInfo().getName());
			}
			if (itemInfo instanceof BoxFolder.Info) {
				BoxFolder childFolder = (BoxFolder) itemInfo.getResource();                
					for (BoxItem.Info childItemInfo : childFolder) {                             		
						if ( childItemInfo instanceof  BoxFile.Info) {                  	 
							BoxFile boxfile = new BoxFile(api, childItemInfo.getID());        		                				    	  								
							fileNameLst.add(boxfile.getInfo().getName());
						}
					}
			}
		}
		System.out.println("ListFiles - File List Size"+fileNameLst.size());
  		return fileNameLst;
	}
}
