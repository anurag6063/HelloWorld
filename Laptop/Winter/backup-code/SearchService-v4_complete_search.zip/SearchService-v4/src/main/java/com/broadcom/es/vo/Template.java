package com.broadcom.es.vo;

import java.util.Map;

public class Template {

	String id;
	Map<String,Object> params;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Map<String, Object> getParams() {
		return params;
	}
	public void setParams(Map<String, Object> searchRequest) {
		this.params = searchRequest;
	}
	
	
}
