package com.cralwer.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

@Component
public class CralwerUtils {

	/*
	 * returns false if some parameter is missing
	 */
	public boolean validateRequest(Map<String,String> params){
		
		if(null == params )
			return false;
		
		
		if(null == params.get("dirWithSubDir") || null == params.get("dir")
				|| StringUtils.isEmpty(params.get("dirWithSubDir"))
						|| StringUtils.isEmpty(params.get("dir"))		
						
				)
		return false;
		
		if(StringUtils.isEmpty(params.get("indexContent")))
			return false;
		
		
		return true;
		
	}

	public String encodeValueBkp(String value) {
        try {
            return URLEncoder.encode(value, StandardCharsets.UTF_8.toString());
        } catch (UnsupportedEncodingException ex) {
            throw new RuntimeException(ex.getCause());
        }
    }

}
