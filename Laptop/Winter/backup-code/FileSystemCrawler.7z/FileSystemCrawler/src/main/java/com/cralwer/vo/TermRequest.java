package com.cralwer.vo;

public class TermRequest {

	
}
