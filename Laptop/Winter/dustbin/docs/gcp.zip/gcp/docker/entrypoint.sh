#!/bin/sh
source /vault/secrets/env_var
rm -rf /vault/secrets/env_var

/home/default/app/analyst-api
